# Hệ thống Quản lý Chuỗi Cà phê Thông minh (Backend Spring Boot)

Dự án triển khai 2 Module lõi theo Tài liệu Phân tích và Thiết kế Hệ thống (Nhóm 8):
1. **Module Bán hàng & Phục vụ (POS, QR Order, Barista KDS)**: UC13, UC14, UC15, UC16, UC17.
2. **Module Kho & Công thức pha chế (Định mức Size S/M/L, Quy đổi đơn vị, Nhập/Kiểm kê, Trừ/Hoàn kho tự động)**: UC18, UC19, UC20, UC21, UC22, UC23.

## Hướng dẫn chạy dự án
1. Đảm bảo đã cài đặt **JDK 17+**, **Maven**, và **MySQL 8.0**.
2. Cập nhật tài khoản MySQL trong `src/main/resources/application.properties` (mặc định `root` / `123456`).
3. Chạy lệnh:
   ```bash
   mvn spring-boot:run
   ```
4. Truy cập tài liệu API trực quan (Swagger UI): `http://localhost:8080/swagger-ui.html`

## Tài khoản kiểm thử mặc định (Mật khẩu: `123456`)
- Quản lý (`MANAGER`): `admin_hd`
- Thu ngân (`CASHIER`): `cashier_hd`
- Pha chế (`BARISTA`): `barista_hd`
- Thủ kho (`STOREKEEPER`): `store_hd`
