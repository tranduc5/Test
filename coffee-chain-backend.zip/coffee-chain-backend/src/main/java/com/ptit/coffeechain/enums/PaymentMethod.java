package com.ptit.coffeechain.enums;

public enum PaymentMethod {
    CASH, VIETQR, CARD, E_WALLET
}
