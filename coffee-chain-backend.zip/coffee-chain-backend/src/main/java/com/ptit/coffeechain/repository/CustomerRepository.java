package com.ptit.coffeechain.repository;
import com.ptit.coffeechain.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
public interface CustomerRepository extends JpaRepository<Customer, Long> {}
