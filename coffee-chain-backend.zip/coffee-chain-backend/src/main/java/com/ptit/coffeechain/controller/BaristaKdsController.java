package com.ptit.coffeechain.controller;

import com.ptit.coffeechain.entity.Order;
import com.ptit.coffeechain.enums.OrderStatus;
import com.ptit.coffeechain.service.BaristaKdsService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/kds")
@RequiredArgsConstructor
public class BaristaKdsController {
    private final BaristaKdsService kdsService;

    // UC17.1: Xem hàng đợi pha chế (FIFO)
    @GetMapping("/branches/{branchId}/orders")
    public ResponseEntity<List<Order>> getKdsQueue(@PathVariable Long branchId) {
        return ResponseEntity.ok(kdsService.getKdsQueue(branchId));
    }

    // UC17.2: Cập nhật trạng thái Đang pha chế / Hoàn thành
    @PatchMapping("/orders/{orderId}/status")
    public ResponseEntity<Order> updateStatus(@PathVariable Long orderId, @RequestParam OrderStatus status) {
        return ResponseEntity.ok(kdsService.updatePreparationStatus(orderId, status));
    }
}
