package com.ptit.coffeechain.repository;
import com.ptit.coffeechain.entity.Branch;
import org.springframework.data.jpa.repository.JpaRepository;
public interface BranchRepository extends JpaRepository<Branch, Long> {}
