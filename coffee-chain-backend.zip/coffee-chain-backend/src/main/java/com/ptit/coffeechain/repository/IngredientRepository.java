package com.ptit.coffeechain.repository;
import com.ptit.coffeechain.entity.Ingredient;
import org.springframework.data.jpa.repository.JpaRepository;
public interface IngredientRepository extends JpaRepository<Ingredient, Long> {}
