package com.ptit.coffeechain.dto;
import com.ptit.coffeechain.enums.PaymentMethod;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;
import java.math.BigDecimal;
import java.util.List;

@Data
public class CreateOrderRequestDTO {
    private Long branchId;
    private Long tableId;
    private String qrToken;
    private Long customerId;
    private BigDecimal discountAmount;
    private PaymentMethod paymentMethod;

    @NotEmpty @Valid
    private List<OrderItemDTO> items;
}
