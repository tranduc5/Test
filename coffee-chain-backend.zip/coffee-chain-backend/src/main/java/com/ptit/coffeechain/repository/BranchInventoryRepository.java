package com.ptit.coffeechain.repository;
import com.ptit.coffeechain.entity.BranchInventory;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;
import java.util.Optional;

public interface BranchInventoryRepository extends JpaRepository<BranchInventory, Long> {
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT bi FROM BranchInventory bi WHERE bi.branch.id = :branchId AND bi.ingredient.id IN :ingredientIds")
    List<BranchInventory> findByBranchAndIngredientsForUpdate(@Param("branchId") Long branchId, @Param("ingredientIds") List<Long> ingredientIds);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT bi FROM BranchInventory bi WHERE bi.branch.id = :branchId AND bi.ingredient.id = :ingredientId")
    Optional<BranchInventory> findByBranchAndIngredientForUpdate(@Param("branchId") Long branchId, @Param("ingredientId") Long ingredientId);

    List<BranchInventory> findByBranchId(Long branchId);
}
