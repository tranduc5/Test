package com.ptit.coffeechain.repository;
import com.ptit.coffeechain.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ProductRepository extends JpaRepository<Product, Long> {}
