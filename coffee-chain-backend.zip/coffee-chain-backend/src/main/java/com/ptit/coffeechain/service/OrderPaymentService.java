package com.ptit.coffeechain.service;

import com.ptit.coffeechain.dto.*;
import com.ptit.coffeechain.entity.*;
import com.ptit.coffeechain.enums.*;
import com.ptit.coffeechain.exception.BusinessException;
import com.ptit.coffeechain.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;

@Service
@RequiredArgsConstructor
public class OrderPaymentService {
    private final OrderRepository orderRepo;
    private final InvoiceRepository invoiceRepo;
    private final ProductSizeRepository productSizeRepo;
    private final CafeTableRepository tableRepo;
    private final BranchRepository branchRepo;
    private final CustomerRepository customerRepo;
    private final InventoryService inventoryService;

    /**
     * UC13: Khách quét QR tạo đơn (Chờ thanh toán VietQR)
     */
    @Transactional
    public Order createQrOrder(CreateOrderRequestDTO dto) {
        if (dto.getQrToken() == null || dto.getQrToken().isBlank()) {
            throw new BusinessException("Thiếu mã QR định danh bàn");
        }
        CafeTable table = tableRepo.findByQrToken(dto.getQrToken())
                .orElseThrow(() -> new BusinessException("Mã bàn không khả dụng, vui lòng liên hệ nhân viên"));

        Order order = buildBaseOrder(dto, table.getBranch(), table, null, OrderChannel.QR_TABLE, OrderStatus.PENDING_PAYMENT);
        return orderRepo.save(order);
    }

    /**
     * UC13: Xác nhận thanh toán VietQR thành công -> Trừ kho -> Chuyển Barista KDS
     */
    @Transactional(rollbackFor = Exception.class)
    public Invoice confirmQrPaymentAndDeductStock(Long orderId) {
        Order order = orderRepo.findById(orderId)
                .orElseThrow(() -> new BusinessException("Không tìm thấy đơn hàng ID: " + orderId));

        if (order.getStatus() != OrderStatus.PENDING_PAYMENT) {
            throw new BusinessException("Đơn hàng không ở trạng thái chờ thanh toán");
        }

        inventoryService.deductStockForOrder(order);

        order.setStatus(OrderStatus.PAID_WAITING);
        orderRepo.save(order);

        Invoice invoice = new Invoice();
        invoice.setInvoiceCode("INV-" + System.currentTimeMillis());
        invoice.setOrder(order);
        invoice.setPaymentMethod(PaymentMethod.VIETQR);
        invoice.setPaidAmount(order.getFinalAmount());
        return invoiceRepo.save(invoice);
    }

    /**
     * UC14: Lập đơn & Thanh toán tại quầy POS
     */
    @Transactional(rollbackFor = Exception.class)
    public Invoice createAndPayPosOrder(CreateOrderRequestDTO dto, Staff cashier) {
        Branch branch = branchRepo.findById(dto.getBranchId())
                .orElseThrow(() -> new BusinessException("Không tìm thấy chi nhánh"));
        CafeTable table = (dto.getTableId() != null)
                ? tableRepo.findById(dto.getTableId()).orElse(null)
                : null;

        Order order = buildBaseOrder(dto, branch, table, cashier, OrderChannel.POS, OrderStatus.PAID_WAITING);
        Order savedOrder = orderRepo.save(order);

        inventoryService.deductStockForOrder(savedOrder);

        Invoice invoice = new Invoice();
        invoice.setInvoiceCode("INV-" + System.currentTimeMillis());
        invoice.setOrder(savedOrder);
        invoice.setCashier(cashier);
        invoice.setPaymentMethod(dto.getPaymentMethod() != null ? dto.getPaymentMethod() : PaymentMethod.CASH);
        invoice.setPaidAmount(savedOrder.getFinalAmount());
        return invoiceRepo.save(invoice);
    }

    /**
     * UC15: Hủy đơn & Hoàn tiền / Hoàn kho
     */
    @Transactional(rollbackFor = Exception.class)
    public Order cancelOrderAndRefundStock(Long orderId, String cancelReason) {
        Order order = orderRepo.findById(orderId)
                .orElseThrow(() -> new BusinessException("Không tìm thấy đơn hàng"));

        if (order.getStatus() == OrderStatus.COMPLETED) {
            throw new BusinessException("Đơn hàng đã hoàn thành pha chế, không thể hủy!");
        }
        if (order.getStatus() == OrderStatus.CANCELLED) {
            throw new BusinessException("Đơn hàng đã bị hủy trước đó!");
        }

        if (order.getStatus() == OrderStatus.PAID_WAITING || order.getStatus() == OrderStatus.PREPARING) {
            inventoryService.refundStockForOrder(order);
        }

        order.setStatus(OrderStatus.CANCELLED);
        return orderRepo.save(order);
    }

    public List<Order> getBranchOrders(Long branchId) {
        return orderRepo.findByBranchIdOrderByCreatedAtDesc(branchId);
    }

    private Order buildBaseOrder(CreateOrderRequestDTO dto, Branch branch, CafeTable table,
                               Staff cashier, OrderChannel channel, OrderStatus status) {
        Order order = new Order();
        order.setOrderCode("ORD-" + System.currentTimeMillis());
        order.setBranch(branch);
        order.setTable(table);
        order.setCashier(cashier);
        if (dto.getCustomerId() != null) {
            customerRepo.findById(dto.getCustomerId()).ifPresent(order::setCustomer);
        }
        order.setOrderChannel(channel);
        order.setStatus(status);

        BigDecimal total = BigDecimal.ZERO;
        List<OrderDetail> details = new ArrayList<>();

        for (OrderItemDTO item : dto.getItems()) {
            ProductSize size = productSizeRepo.findById(item.getProductSizeId())
                    .orElseThrow(() -> new BusinessException("Kích cỡ món không tồn tại ID: " + item.getProductSizeId()));
            BigDecimal unitPrice = size.getProduct().getBasePrice().add(size.getPriceAdjustment());

            OrderDetail detail = new OrderDetail();
            detail.setOrder(order);
            detail.setProductSize(size);
            detail.setQuantity(item.getQuantity());
            detail.setUnitPrice(unitPrice);
            detail.setSugarLevel(item.getSugarLevel());
            detail.setIceLevel(item.getIceLevel());
            detail.setNote(item.getNote());
            details.add(detail);

            total = total.add(unitPrice.multiply(BigDecimal.valueOf(item.getQuantity())));
        }

        BigDecimal discount = dto.getDiscountAmount() != null ? dto.getDiscountAmount() : BigDecimal.ZERO;
        order.setTotalAmount(total);
        order.setDiscountAmount(discount);
        order.setFinalAmount(total.subtract(discount).max(BigDecimal.ZERO));
        order.setListOrderDetails(details);
        return order;
    }
}
