package com.ptit.coffeechain.dto;
import com.ptit.coffeechain.entity.ProductSize;
import lombok.Builder;
import lombok.Data;
import java.math.BigDecimal;
import java.util.List;

@Data @Builder
public class MenuProductResponseDTO {
    private Long id;
    private String code;
    private String name;
    private String categoryName;
    private BigDecimal basePrice;
    private boolean availableAtBranch; // Tính động theo tồn kho chi nhánh
    private List<ProductSize> sizes;
}
