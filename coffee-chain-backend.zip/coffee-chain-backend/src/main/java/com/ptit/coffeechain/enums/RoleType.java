package com.ptit.coffeechain.enums;

public enum RoleType {
    MANAGER, CASHIER, BARISTA, STOREKEEPER, CUSTOMER
}
