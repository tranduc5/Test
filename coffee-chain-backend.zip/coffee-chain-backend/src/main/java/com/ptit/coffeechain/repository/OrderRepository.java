package com.ptit.coffeechain.repository;
import com.ptit.coffeechain.entity.Order;
import com.ptit.coffeechain.enums.OrderStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface OrderRepository extends JpaRepository<Order, Long> {
    List<Order> findByBranchIdAndStatusInOrderByCreatedAtAsc(Long branchId, List<OrderStatus> statuses);
    List<Order> findByBranchIdOrderByCreatedAtDesc(Long branchId);
}
