package com.ptit.coffeechain.repository;
import com.ptit.coffeechain.entity.StockTransaction;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface StockTransactionRepository extends JpaRepository<StockTransaction, Long> {
    List<StockTransaction> findByBranchIdOrderByCreatedAtDesc(Long branchId);
}
