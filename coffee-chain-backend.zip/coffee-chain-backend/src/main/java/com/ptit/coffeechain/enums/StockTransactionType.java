package com.ptit.coffeechain.enums;

public enum StockTransactionType {
    ORDER_DEDUCT,
    ORDER_REFUND,
    IMPORT,
    STOCK_AUDIT,
    DISPOSAL
}
