package com.ptit.coffeechain.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .csrf(AbstractHttpConfigurer::disable)
            .authorizeHttpRequests(auth -> auth
                // Khách hàng quét QR đặt món & thanh toán không cần đăng nhập
                .requestMatchers("/api/qr/**", "/api/menu/**", "/api/orders/*/confirm-payment").permitAll()
                .requestMatchers("/swagger-ui/**", "/v3/api-docs/**").permitAll()
                // Phân quyền theo Actor
                .requestMatchers("/api/pos/**", "/api/orders/*/cancel").hasAnyRole("CASHIER", "MANAGER")
                .requestMatchers("/api/kds/**").hasAnyRole("BARISTA", "MANAGER")
                .requestMatchers("/api/recipes/**").hasRole("MANAGER")
                .requestMatchers("/api/inventory/**").hasAnyRole("STOREKEEPER", "MANAGER")
                .anyRequest().authenticated()
            )
            .httpBasic(Customizer.withDefaults());
        return http.build();
    }
}
