package com.ptit.coffeechain.repository;
import com.ptit.coffeechain.entity.Invoice;
import org.springframework.data.jpa.repository.JpaRepository;
public interface InvoiceRepository extends JpaRepository<Invoice, Long> {}
