package com.ptit.coffeechain.enums;

public enum OrderChannel {
    POS, QR_TABLE
}
