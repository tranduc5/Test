package com.ptit.coffeechain.service;

import com.ptit.coffeechain.dto.RecipeItemRequestDTO;
import com.ptit.coffeechain.entity.*;
import com.ptit.coffeechain.exception.BusinessException;
import com.ptit.coffeechain.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class RecipeService {
    private final ProductSizeRepository productSizeRepo;
    private final RecipeItemRepository recipeItemRepo;
    private final IngredientRepository ingredientRepo;

    public List<RecipeItem> getRecipesByProduct(Long productId) {
        List<Long> sizeIds = productSizeRepo.findByProductId(productId).stream()
                .map(ProductSize::getId).toList();
        if (sizeIds.isEmpty()) return List.of();
        return recipeItemRepo.findByProductSizeIdIn(sizeIds);
    }

    @Transactional
    public List<RecipeItem> saveRecipeItems(Long productSizeId, List<RecipeItemRequestDTO> items) {
        ProductSize size = productSizeRepo.findById(productSizeId)
                .orElseThrow(() -> new BusinessException("Không tìm thấy kích cỡ sản phẩm ID: " + productSizeId));

        Set<Long> uniqueIngIds = new HashSet<>();
        for (RecipeItemRequestDTO dto : items) {
            if (dto.getQuantityRequired() == null || dto.getQuantityRequired() <= 0) {
                throw new BusinessException("Định lượng nguyên liệu phải lớn hơn 0");
            }
            if (!uniqueIngIds.add(dto.getIngredientId())) {
                throw new BusinessException("Không được khai báo trùng nguyên liệu trong cùng một Size");
            }
        }

        recipeItemRepo.deleteByProductSizeId(productSizeId);

        List<RecipeItem> entities = items.stream().map(dto -> {
            Ingredient ing = ingredientRepo.findById(dto.getIngredientId())
                    .orElseThrow(() -> new BusinessException("Không tìm thấy nguyên liệu ID: " + dto.getIngredientId()));
            RecipeItem ri = new RecipeItem();
            ri.setProductSize(size);
            ri.setIngredient(ing);
            ri.setQuantityRequired(dto.getQuantityRequired());
            ri.setWastagePercent(dto.getWastagePercent() != null ? dto.getWastagePercent() : 0.0);
            return ri;
        }).collect(Collectors.toList());

        return recipeItemRepo.saveAll(entities);
    }
}
