package com.ptit.coffeechain.dto;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;

@Data
public class RecipeItemRequestDTO {
    @NotNull
    private Long ingredientId;
    @NotNull @Positive
    private Double quantityRequired;
    private Double wastagePercent = 0.0;
}
