package com.ptit.coffeechain.controller;

import com.ptit.coffeechain.dto.CreateOrderRequestDTO;
import com.ptit.coffeechain.dto.MenuProductResponseDTO;
import com.ptit.coffeechain.entity.*;
import com.ptit.coffeechain.repository.CafeTableRepository;
import com.ptit.coffeechain.repository.StaffRepository;
import com.ptit.coffeechain.service.InventoryService;
import com.ptit.coffeechain.service.OrderPaymentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class SalesOrderController {
    private final OrderPaymentService orderPaymentService;
    private final InventoryService inventoryService;
    private final CafeTableRepository tableRepo;
    private final StaffRepository staffRepo;

    // UC13.1: Quét mã QR lấy thông tin bàn & E-Menu động theo tồn kho chi nhánh
    @GetMapping("/qr/tables/{qrToken}/menu")
    public ResponseEntity<Map<String, Object>> getMenuByQr(@PathVariable String qrToken) {
        CafeTable table = tableRepo.findByQrToken(qrToken)
                .orElseThrow(() -> new RuntimeException("Mã QR bàn không hợp lệ"));
        List<MenuProductResponseDTO> menu = inventoryService.getBranchMenu(table.getBranch().getId());
        return ResponseEntity.ok(Map.of(
                "branchName", table.getBranch().getName(),
                "tableName", table.getTableName(),
                "menu", menu
        ));
    }

    // Lấy thực đơn tại chi nhánh cho màn hình POS
    @GetMapping("/menu/branches/{branchId}")
    public ResponseEntity<List<MenuProductResponseDTO>> getBranchMenu(@PathVariable Long branchId) {
        return ResponseEntity.ok(inventoryService.getBranchMenu(branchId));
    }

    // UC13: Khách tạo đơn từ QR
    @PostMapping("/qr/orders")
    public ResponseEntity<Order> createQrOrder(@Valid @RequestBody CreateOrderRequestDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(orderPaymentService.createQrOrder(dto));
    }

    // UC13: Xác nhận thanh toán VietQR -> Tự động trừ kho & đẩy Barista
    @PostMapping("/orders/{orderId}/confirm-payment")
    public ResponseEntity<Invoice> confirmQrPayment(@PathVariable Long orderId) {
        return ResponseEntity.ok(orderPaymentService.confirmQrPaymentAndDeductStock(orderId));
    }

    // UC14: Thu ngân lập đơn và thanh toán tại quầy POS
    @PostMapping("/pos/orders")
    public ResponseEntity<Invoice> createAndPayPos(@Valid @RequestBody CreateOrderRequestDTO dto, Authentication auth) {
        Staff cashier = (auth != null) ? staffRepo.findByUsername(auth.getName()).orElse(null) : null;
        return ResponseEntity.status(HttpStatus.CREATED).body(orderPaymentService.createAndPayPosOrder(dto, cashier));
    }

    // UC15: Hủy đơn và hoàn trả tồn kho
    @PostMapping("/orders/{orderId}/cancel")
    public ResponseEntity<Order> cancelOrder(@PathVariable Long orderId, @RequestParam String reason) {
        return ResponseEntity.ok(orderPaymentService.cancelOrderAndRefundStock(orderId, reason));
    }

    // UC16: Tra cứu lịch sử đơn hàng theo chi nhánh
    @GetMapping("/pos/branches/{branchId}/orders")
    public ResponseEntity<List<Order>> getBranchOrders(@PathVariable Long branchId) {
        return ResponseEntity.ok(orderPaymentService.getBranchOrders(branchId));
    }
}
