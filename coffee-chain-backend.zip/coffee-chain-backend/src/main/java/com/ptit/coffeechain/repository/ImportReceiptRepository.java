package com.ptit.coffeechain.repository;
import com.ptit.coffeechain.entity.ImportReceipt;
import org.springframework.data.jpa.repository.JpaRepository;
public interface ImportReceiptRepository extends JpaRepository<ImportReceipt, Long> {}
