package com.ptit.coffeechain.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "tblBranch")
@Data @NoArgsConstructor @AllArgsConstructor
public class Branch {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 20)
    private String code;

    @Column(nullable = false, length = 100)
    private String name;

    @Column(nullable = false)
    private String address;

    @Column(length = 15)
    private String phone;

    @Column(nullable = false)
    private Boolean status = true;
}
