package com.ptit.coffeechain.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "tblCustomer")
@PrimaryKeyJoinColumn(name = "member_id")
@Data @EqualsAndHashCode(callSuper = true)
@NoArgsConstructor @AllArgsConstructor
public class Customer extends Member {
    @Column(nullable = false, length = 20)
    private String tier = "STANDARD";

    @Column(name = "accumulated_points", nullable = false)
    private Integer accumulatedPoints = 0;
}
