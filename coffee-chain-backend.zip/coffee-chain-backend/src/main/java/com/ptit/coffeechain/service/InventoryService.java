package com.ptit.coffeechain.service;

import com.ptit.coffeechain.dto.*;
import com.ptit.coffeechain.entity.*;
import com.ptit.coffeechain.enums.StockTransactionType;
import com.ptit.coffeechain.exception.*;
import com.ptit.coffeechain.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class InventoryService {
    private final BranchInventoryRepository inventoryRepo;
    private final RecipeItemRepository recipeRepo;
    private final IngredientRepository ingredientRepo;
    private final ImportReceiptRepository importReceiptRepo;
    private final StockTransactionRepository transactionRepo;
    private final BranchRepository branchRepo;
    private final SupplierRepository supplierRepo;
    private final ProductRepository productRepo;

    public List<BranchInventory> getBranchInventory(Long branchId) {
        return inventoryRepo.findByBranchId(branchId);
    }

    public List<BranchInventory> getLowStockAlerts(Long branchId) {
        return inventoryRepo.findByBranchId(branchId).stream()
                .filter(bi -> bi.getCurrentQuantity() <= bi.getIngredient().getMinStockThreshold())
                .toList();
    }

    /**
     * Tính trạng thái còn hàng động theo tồn kho của từng chi nhánh (E-Menu & POS)
     */
    public List<MenuProductResponseDTO> getBranchMenu(Long branchId) {
        Map<Long, Double> stockMap = inventoryRepo.findByBranchId(branchId).stream()
                .collect(Collectors.toMap(bi -> bi.getIngredient().getId(), BranchInventory::getCurrentQuantity));

        return productRepo.findAll().stream().map(p -> {
            boolean hasEnoughStock = Boolean.TRUE.equals(p.getIsAvailable()) && checkProductStockAvailable(p, stockMap);
            return MenuProductResponseDTO.builder()
                    .id(p.getId())
                    .code(p.getCode())
                    .name(p.getName())
                    .categoryName(p.getCategory().getName())
                    .basePrice(p.getBasePrice())
                    .availableAtBranch(hasEnoughStock)
                    .sizes(p.getListSizes())
                    .build();
        }).toList();
    }

    private boolean checkProductStockAvailable(Product p, Map<Long, Double> stockMap) {
        if (p.getListSizes() == null || p.getListSizes().isEmpty()) return true;
        // Chỉ cần ít nhất 1 size còn đủ nguyên liệu thì món vẫn mở bán
        for (ProductSize size : p.getListSizes()) {
            List<RecipeItem> recipes = recipeRepo.findByProductSizeId(size.getId());
            boolean sizeOk = true;
            for (RecipeItem r : recipes) {
                double needed = r.getQuantityRequired() * (1.0 + r.getWastagePercent() / 100.0);
                if (stockMap.getOrDefault(r.getIngredient().getId(), 0.0) < needed) {
                    sizeOk = false;
                    break;
                }
            }
            if (sizeOk) return true;
        }
        return false;
    }

    /**
     * UC23: Tự động trừ kho theo công thức khi thanh toán thành công
     */
    @Transactional(rollbackFor = Exception.class)
    public void deductStockForOrder(Order order) {
        Map<Long, Double> requiredMap = calculateTotalIngredientsNeeded(order);
        if (requiredMap.isEmpty()) return;

        List<BranchInventory> inventories = inventoryRepo.findByBranchAndIngredientsForUpdate(
                order.getBranch().getId(), new ArrayList<>(requiredMap.keySet()));
        Map<Long, BranchInventory> invMap = inventories.stream()
                .collect(Collectors.toMap(bi -> bi.getIngredient().getId(), bi -> bi));

        List<StockTransaction> logs = new ArrayList<>();
        for (Map.Entry<Long, Double> entry : requiredMap.entrySet()) {
            Long ingId = entry.getKey();
            Double needed = entry.getValue();
            BranchInventory bi = invMap.get(ingId);

            if (bi == null || bi.getCurrentQuantity() < needed) {
                String name = (bi != null) ? bi.getIngredient().getName() : "ID " + ingId;
                throw new InsufficientStockException("Nguyên liệu [" + name + "] đã hết hoặc không đủ tồn kho!");
            }

            bi.setCurrentQuantity(bi.getCurrentQuantity() - needed);
            logs.add(StockTransaction.builder()
                    .branch(order.getBranch())
                    .ingredient(bi.getIngredient())
                    .transactionType(StockTransactionType.ORDER_DEDUCT)
                    .quantityChange(-needed)
                    .referenceCode(order.getOrderCode())
                    .note("Tự động trừ kho theo đơn hàng " + order.getOrderCode())
                    .build());
        }

        inventoryRepo.saveAll(inventories);
        transactionRepo.saveAll(logs);
    }

    /**
     * UC23: Tự động hoàn kho khi hủy đơn hợp lệ (UC15)
     */
    @Transactional(rollbackFor = Exception.class)
    public void refundStockForOrder(Order order) {
        Map<Long, Double> refundMap = calculateTotalIngredientsNeeded(order);
        if (refundMap.isEmpty()) return;

        List<BranchInventory> inventories = inventoryRepo.findByBranchAndIngredientsForUpdate(
                order.getBranch().getId(), new ArrayList<>(refundMap.keySet()));
        Map<Long, BranchInventory> invMap = inventories.stream()
                .collect(Collectors.toMap(bi -> bi.getIngredient().getId(), bi -> bi));

        List<StockTransaction> logs = new ArrayList<>();
        for (Map.Entry<Long, Double> entry : refundMap.entrySet()) {
            BranchInventory bi = invMap.get(entry.getKey());
            if (bi != null) {
                bi.setCurrentQuantity(bi.getCurrentQuantity() + entry.getValue());
                logs.add(StockTransaction.builder()
                        .branch(order.getBranch())
                        .ingredient(bi.getIngredient())
                        .transactionType(StockTransactionType.ORDER_REFUND)
                        .quantityChange(entry.getValue())
                        .referenceCode(order.getOrderCode())
                        .note("Hoàn trả nguyên liệu do hủy đơn " + order.getOrderCode())
                        .build());
            }
        }
        inventoryRepo.saveAll(inventories);
        transactionRepo.saveAll(logs);
    }

    /**
     * UC21: Nhập kho nguyên vật liệu & Quy đổi đơn vị tự động
     */
    @Transactional(rollbackFor = Exception.class)
    public ImportReceipt createImportReceipt(ImportReceiptRequestDTO dto, Staff storekeeper) {
        Branch branch = branchRepo.findById(dto.getBranchId())
                .orElseThrow(() -> new BusinessException("Không tìm thấy chi nhánh"));
        Supplier supplier = supplierRepo.findById(dto.getSupplierId())
                .orElseThrow(() -> new BusinessException("Không tìm thấy nhà cung cấp"));

        ImportReceipt receipt = new ImportReceipt();
        receipt.setReceiptCode("PN-" + System.currentTimeMillis());
        receipt.setBranch(branch);
        receipt.setSupplier(supplier);
        receipt.setStorekeeper(storekeeper);

        BigDecimal totalCost = BigDecimal.ZERO;
        List<ImportReceiptDetail> details = new ArrayList<>();

        for (ImportItemDTO item : dto.getItems()) {
            if (item.getExpiryDate() != null && !item.getExpiryDate().isAfter(LocalDate.now())) {
                throw new BusinessException("Nguyên liệu đã hết hạn sử dụng, từ chối nhập kho!");
            }

            Ingredient ing = ingredientRepo.findById(item.getIngredientId())
                    .orElseThrow(() -> new BusinessException("Không tìm thấy nguyên liệu ID: " + item.getIngredientId()));

            double convertedBaseQty = item.getImportQuantity() * ing.getConversionRate();

            ImportReceiptDetail detail = new ImportReceiptDetail();
            detail.setImportReceipt(receipt);
            detail.setIngredient(ing);
            detail.setImportQuantity(item.getImportQuantity());
            detail.setConvertedBaseQty(convertedBaseQty);
            detail.setImportPrice(item.getImportPrice());
            detail.setExpiryDate(item.getExpiryDate());
            details.add(detail);

            totalCost = totalCost.add(item.getImportPrice().multiply(BigDecimal.valueOf(item.getImportQuantity())));

            BranchInventory bi = inventoryRepo.findByBranchAndIngredientForUpdate(branch.getId(), ing.getId())
                    .orElseGet(() -> new BranchInventory(null, branch, ing, 0.0, LocalDateTime.now()));
            bi.setCurrentQuantity(bi.getCurrentQuantity() + convertedBaseQty);
            inventoryRepo.save(bi);

            transactionRepo.save(StockTransaction.builder()
                    .branch(branch)
                    .ingredient(ing)
                    .transactionType(StockTransactionType.IMPORT)
                    .quantityChange(convertedBaseQty)
                    .referenceCode(receipt.getReceiptCode())
                    .note("Nhập kho từ NCC " + supplier.getName())
                    .build());
        }

        receipt.setTotalCostImport(totalCost);
        receipt.setListImportDetails(details);
        return importReceiptRepo.save(receipt);
    }

    /**
     * UC22: Kiểm kê đối soát tồn thực tế & Xuất hủy kho
     */
    @Transactional(rollbackFor = Exception.class)
    public StockTransaction adjustOrDisposeStock(Long branchId, Long ingredientId, Double quantity, boolean isDisposal, String reason) {
        BranchInventory bi = inventoryRepo.findByBranchAndIngredientForUpdate(branchId, ingredientId)
                .orElseThrow(() -> new BusinessException("Không tìm thấy bản ghi tồn kho tại chi nhánh"));

        double diff;
        StockTransactionType type;
        if (isDisposal) {
            if (quantity <= 0 || bi.getCurrentQuantity() < quantity) {
                throw new BusinessException("Số lượng xuất hủy không hợp lệ hoặc vượt quá tồn kho hiện tại");
            }
            diff = -quantity;
            bi.setCurrentQuantity(bi.getCurrentQuantity() + diff);
            type = StockTransactionType.DISPOSAL;
        } else {
            if (quantity < 0) throw new BusinessException("Số lượng kiểm kê thực tế không được âm");
            diff = quantity - bi.getCurrentQuantity();
            bi.setCurrentQuantity(quantity);
            type = StockTransactionType.STOCK_AUDIT;
        }

        inventoryRepo.save(bi);
        return transactionRepo.save(StockTransaction.builder()
                .branch(bi.getBranch())
                .ingredient(bi.getIngredient())
                .transactionType(type)
                .quantityChange(diff)
                .referenceCode("KK-" + System.currentTimeMillis())
                .note(reason)
                .build());
    }

    private Map<Long, Double> calculateTotalIngredientsNeeded(Order order) {
        Map<Long, Double> map = new HashMap<>();
        for (OrderDetail detail : order.getListOrderDetails()) {
            List<RecipeItem> recipes = recipeRepo.findByProductSizeId(detail.getProductSize().getId());
            for (RecipeItem r : recipes) {
                double factor = 1.0 + (r.getWastagePercent() / 100.0);
                double qty = r.getQuantityRequired() * factor * detail.getQuantity();
                map.merge(r.getIngredient().getId(), qty, Double::sum);
            }
        }
        return map;
    }
}
