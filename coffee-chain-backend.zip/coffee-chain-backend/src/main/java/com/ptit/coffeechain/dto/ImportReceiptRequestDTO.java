package com.ptit.coffeechain.dto;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.util.List;

@Data
public class ImportReceiptRequestDTO {
    @NotNull
    private Long branchId;
    @NotNull
    private Long supplierId;
    @NotEmpty @Valid
    private List<ImportItemDTO> items;
}
