package com.ptit.coffeechain;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoffeeChainApplication {
    public static void main(String[] args) {
        SpringApplication.run(CoffeeChainApplication.class, args);
    }
}
