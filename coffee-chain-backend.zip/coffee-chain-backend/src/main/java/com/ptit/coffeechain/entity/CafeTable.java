package com.ptit.coffeechain.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "tblCafeTable")
@Data @NoArgsConstructor @AllArgsConstructor
public class CafeTable {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "branch_id", nullable = false)
    private Branch branch;

    @Column(name = "table_name", nullable = false, length = 50)
    private String tableName;

    @Column(name = "qr_token", nullable = false, unique = true, length = 100)
    private String qrToken;

    @Column(nullable = false, length = 20)
    private String status = "AVAILABLE";
}
