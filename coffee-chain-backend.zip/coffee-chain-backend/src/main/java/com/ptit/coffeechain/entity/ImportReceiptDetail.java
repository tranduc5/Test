package com.ptit.coffeechain.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "tblImportReceiptDetail")
@Data @NoArgsConstructor @AllArgsConstructor
public class ImportReceiptDetail {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "import_receipt_id", nullable = false)
    private ImportReceipt importReceipt;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ingredient_id", nullable = false)
    private Ingredient ingredient;

    @Column(name = "import_quantity", nullable = false)
    private Double importQuantity;

    @Column(name = "converted_base_qty", nullable = false)
    private Double convertedBaseQty;

    @Column(name = "import_price", nullable = false, precision = 12, scale = 2)
    private BigDecimal importPrice;

    @Column(name = "expiry_date")
    private LocalDate expiryDate;
}
