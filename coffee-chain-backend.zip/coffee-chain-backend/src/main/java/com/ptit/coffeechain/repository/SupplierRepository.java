package com.ptit.coffeechain.repository;
import com.ptit.coffeechain.entity.Supplier;
import org.springframework.data.jpa.repository.JpaRepository;
public interface SupplierRepository extends JpaRepository<Supplier, Long> {}
