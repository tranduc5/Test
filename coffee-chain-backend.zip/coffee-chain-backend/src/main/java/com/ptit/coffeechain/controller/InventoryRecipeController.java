package com.ptit.coffeechain.controller;

import com.ptit.coffeechain.dto.ImportReceiptRequestDTO;
import com.ptit.coffeechain.dto.RecipeItemRequestDTO;
import com.ptit.coffeechain.entity.*;
import com.ptit.coffeechain.repository.StaffRepository;
import com.ptit.coffeechain.repository.StockTransactionRepository;
import com.ptit.coffeechain.service.InventoryService;
import com.ptit.coffeechain.service.RecipeService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class InventoryRecipeController {
    private final RecipeService recipeService;
    private final InventoryService inventoryService;
    private final StaffRepository staffRepo;
    private final StockTransactionRepository transactionRepo;

    // UC19: Xem công thức định mức của món
    @GetMapping("/recipes/products/{productId}")
    public ResponseEntity<List<RecipeItem>> getProductRecipes(@PathVariable Long productId) {
        return ResponseEntity.ok(recipeService.getRecipesByProduct(productId));
    }

    // UC19: Thiết lập định mức công thức cho từng Size (S/M/L)
    @PostMapping("/recipes/product-sizes/{sizeId}")
    public ResponseEntity<List<RecipeItem>> saveRecipes(
            @PathVariable Long sizeId,
            @Valid @RequestBody List<RecipeItemRequestDTO> items) {
        return ResponseEntity.ok(recipeService.saveRecipeItems(sizeId, items));
    }

    // Xem tồn kho hiện tại của chi nhánh
    @GetMapping("/inventory/branches/{branchId}")
    public ResponseEntity<List<BranchInventory>> getBranchInventory(@PathVariable Long branchId) {
        return ResponseEntity.ok(inventoryService.getBranchInventory(branchId));
    }

    // Cảnh báo nguyên liệu chạm ngưỡng tối thiểu
    @GetMapping("/inventory/branches/{branchId}/alerts")
    public ResponseEntity<List<BranchInventory>> getLowStockAlerts(@PathVariable Long branchId) {
        return ResponseEntity.ok(inventoryService.getLowStockAlerts(branchId));
    }

    // UC21: Nhập kho nguyên vật liệu & Tự động quy đổi đơn vị
    @PostMapping("/inventory/import-receipts")
    public ResponseEntity<ImportReceipt> createImportReceipt(
            @Valid @RequestBody ImportReceiptRequestDTO dto,
            Authentication auth) {
        Staff storekeeper = (auth != null) ? staffRepo.findByUsername(auth.getName()).orElse(null) : null;
        return ResponseEntity.status(HttpStatus.CREATED).body(inventoryService.createImportReceipt(dto, storekeeper));
    }

    // UC22: Kiểm kê tồn thực tế hoặc Xuất hủy nguyên liệu hỏng
    @PostMapping("/inventory/stock-adjust")
    public ResponseEntity<StockTransaction> adjustOrDisposeStock(
            @RequestParam Long branchId,
            @RequestParam Long ingredientId,
            @RequestParam Double quantity,
            @RequestParam boolean isDisposal,
            @RequestParam String reason) {
        return ResponseEntity.ok(inventoryService.adjustOrDisposeStock(branchId, ingredientId, quantity, isDisposal, reason));
    }

    // Lịch sử biến động kho chi nhánh
    @GetMapping("/inventory/branches/{branchId}/transactions")
    public ResponseEntity<List<StockTransaction>> getStockTransactions(@PathVariable Long branchId) {
        return ResponseEntity.ok(transactionRepo.findByBranchIdOrderByCreatedAtDesc(branchId));
    }
}
