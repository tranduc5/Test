package com.ptit.coffeechain.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "tblCategory")
@Data @NoArgsConstructor @AllArgsConstructor
public class Category {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String name;

    @Column(name = "display_order", nullable = false)
    private Integer displayOrder = 0;
}
