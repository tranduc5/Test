package com.ptit.coffeechain.dto;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class OrderItemDTO {
    @NotNull
    private Long productSizeId;
    @NotNull @Min(1)
    private Integer quantity;
    private String sugarLevel;
    private String iceLevel;
    private String note;
}
