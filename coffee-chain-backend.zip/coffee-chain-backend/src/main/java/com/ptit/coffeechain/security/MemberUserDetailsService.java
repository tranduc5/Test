package com.ptit.coffeechain.security;

import com.ptit.coffeechain.entity.Member;
import com.ptit.coffeechain.repository.MemberRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.*;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@RequiredArgsConstructor
public class MemberUserDetailsService implements UserDetailsService {
    private final MemberRepository memberRepo;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Member m = memberRepo.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("Không tìm thấy tài khoản: " + username));
        return new User(
                m.getUsername(),
                m.getPasswordHash(),
                m.getActive(),
                true, true, true,
                List.of(new SimpleGrantedAuthority("ROLE_" + m.getRole().name()))
        );
    }
}
