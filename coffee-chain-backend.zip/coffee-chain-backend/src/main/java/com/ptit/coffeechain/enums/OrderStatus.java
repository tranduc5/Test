package com.ptit.coffeechain.enums;

public enum OrderStatus {
    PENDING_PAYMENT,
    PAID_WAITING,
    PREPARING,
    COMPLETED,
    CANCELLED
}
