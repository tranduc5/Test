package com.ptit.coffeechain.repository;
import com.ptit.coffeechain.entity.RecipeItem;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface RecipeItemRepository extends JpaRepository<RecipeItem, Long> {
    List<RecipeItem> findByProductSizeId(Long productSizeId);
    List<RecipeItem> findByProductSizeIdIn(List<Long> sizeIds);
    void deleteByProductSizeId(Long productSizeId);
}
