package com.ptit.coffeechain.service;

import com.ptit.coffeechain.entity.Order;
import com.ptit.coffeechain.enums.OrderStatus;
import com.ptit.coffeechain.exception.BusinessException;
import com.ptit.coffeechain.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@RequiredArgsConstructor
public class BaristaKdsService {
    private final OrderRepository orderRepo;

    // UC17.1: Lấy danh sách đơn hàng đã thanh toán theo thứ tự FIFO
    public List<Order> getKdsQueue(Long branchId) {
        return orderRepo.findByBranchIdAndStatusInOrderByCreatedAtAsc(
                branchId, List.of(OrderStatus.PAID_WAITING, OrderStatus.PREPARING));
    }

    // UC17.2: Cập nhật trạng thái Đang pha chế / Hoàn thành
    @Transactional
    public Order updatePreparationStatus(Long orderId, OrderStatus nextStatus) {
        Order order = orderRepo.findById(orderId)
                .orElseThrow(() -> new BusinessException("Không tìm thấy đơn hàng"));

        if (order.getStatus() == OrderStatus.PAID_WAITING && nextStatus == OrderStatus.PREPARING) {
            order.setStatus(OrderStatus.PREPARING);
        } else if (order.getStatus() == OrderStatus.PREPARING && nextStatus == OrderStatus.COMPLETED) {
            order.setStatus(OrderStatus.COMPLETED);
        } else {
            throw new BusinessException("Chuyển trạng thái pha chế không hợp lệ: " + order.getStatus() + " -> " + nextStatus);
        }
        return orderRepo.save(order);
    }
}
