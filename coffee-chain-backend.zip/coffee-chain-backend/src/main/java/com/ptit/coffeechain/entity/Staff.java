package com.ptit.coffeechain.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "tblStaff")
@PrimaryKeyJoinColumn(name = "member_id")
@Data @EqualsAndHashCode(callSuper = true)
@NoArgsConstructor @AllArgsConstructor
public class Staff extends Member {
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "branch_id")
    private Branch branch;

    @Column(nullable = false, length = 50)
    private String position;

    @Column(name = "station_code", length = 30)
    private String stationCode;
}
