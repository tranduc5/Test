package com.ptit.coffeechain.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.UpdateTimestamp;
import java.time.LocalDateTime;

@Entity
@Table(name = "tblBranchInventory", uniqueConstraints = {
    @UniqueConstraint(name = "uk_branch_ingredient", columnNames = {"branch_id", "ingredient_id"})
})
@Data @NoArgsConstructor @AllArgsConstructor
public class BranchInventory {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "branch_id", nullable = false)
    private Branch branch;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ingredient_id", nullable = false)
    private Ingredient ingredient;

    @Column(name = "current_quantity", nullable = false)
    private Double currentQuantity = 0.0;

    @UpdateTimestamp
    @Column(name = "last_updated", nullable = false)
    private LocalDateTime lastUpdated;
}
