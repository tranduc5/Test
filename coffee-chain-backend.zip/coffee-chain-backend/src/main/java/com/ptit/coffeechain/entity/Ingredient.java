package com.ptit.coffeechain.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "tblIngredient")
@Data @NoArgsConstructor @AllArgsConstructor
public class Ingredient {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 30)
    private String code;

    @Column(nullable = false, length = 150)
    private String name;

    @Column(name = "base_unit", nullable = false, length = 20)
    private String baseUnit;

    @Column(name = "conversion_unit", nullable = false, length = 20)
    private String conversionUnit;

    @Column(name = "conversion_rate", nullable = false)
    private Double conversionRate = 1.0;

    @Column(name = "min_stock_threshold", nullable = false)
    private Double minStockThreshold = 0.0;
}
