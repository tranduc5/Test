package com.ptit.coffeechain.dto;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;
import java.math.BigDecimal;
import java.time.LocalDate;

@Data
public class ImportItemDTO {
    @NotNull
    private Long ingredientId;
    @NotNull @Positive
    private Double importQuantity;
    @NotNull @Positive
    private BigDecimal importPrice;
    private LocalDate expiryDate;
}
