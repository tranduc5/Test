-- Dữ liệu mẫu khởi tạo phục vụ kiểm thử
INSERT IGNORE INTO tblBranch (id, code, name, address, phone, status) VALUES
(1, 'CN-HD', 'HN Cà Phê - Chi nhánh Hà Đông', '102 Trần Phú, Hà Đông, Hà Nội', '0243888999', 1),
(2, 'CN-CG', 'HN Cà Phê - Chi nhánh Cầu Giấy', '25 Xuân Thủy, Cầu Giấy, Hà Nội', '0243777666', 1);

-- Mật khẩu mặc định: 123456 (BCrypt)
INSERT IGNORE INTO tblMember (id, username, password_hash, full_name, phone, email, role, active) VALUES
(1, 'admin_hd', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'Nguyễn Văn Quản Lý', '0901000001', 'manager@hncafe.vn', 'MANAGER', 1),
(2, 'cashier_hd', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'Trần Thị Thu Ngân', '0901000002', 'cashier@hncafe.vn', 'CASHIER', 1),
(3, 'barista_hd', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'Lê Văn Pha Chế', '0901000003', 'barista@hncafe.vn', 'BARISTA', 1),
(4, 'store_hd', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy', 'Phạm Thị Thủ Kho', '0901000004', 'storekeeper@hncafe.vn', 'STOREKEEPER', 1);

INSERT IGNORE INTO tblStaff (member_id, branch_id, position, station_code) VALUES
(1, 1, 'Quản lý chi nhánh', 'MGR-01'),
(2, 1, 'Thu ngân quầy chính', 'POS-01'),
(3, 1, 'Pha chế trưởng', 'BAR-01'),
(4, 1, 'Thủ kho chi nhánh', 'WH-01');

INSERT IGNORE INTO tblCafeTable (id, branch_id, table_name, qr_token, status) VALUES
(1, 1, 'Bàn 01 - Tầng 1', 'QR-CNHD-T01', 'AVAILABLE'),
(2, 1, 'Bàn 02 - Tầng 1', 'QR-CNHD-T02', 'AVAILABLE'),
(3, 1, 'Bàn 08 - Ban công', 'QR-CNHD-T08', 'AVAILABLE');

INSERT IGNORE INTO tblCategory (id, name, display_order) VALUES
(1, 'Cà phê truyền thống', 1),
(2, 'Trà trái cây', 2),
(3, 'Topping thêm', 3);

INSERT IGNORE INTO tblProduct (id, category_id, code, name, base_price, is_available) VALUES
(1, 1, 'CF-SUADA', 'Cà phê Sữa Đá', 29000.00, 1),
(2, 1, 'CF-BACXIU', 'Bạc Xỉu', 35000.00, 1),
(3, 2, 'TR-DAOCAMSA', 'Trà Đào Cam Sả', 45000.00, 1),
(4, 3, 'TOP-TRANCHAU', 'Trân châu trắng', 8000.00, 1);

INSERT IGNORE INTO tblProductSize (id, product_id, size_name, price_adjustment) VALUES
(1, 1, 'S', 0.00),
(2, 1, 'M', 6000.00),
(3, 1, 'L', 12000.00),
(4, 2, 'M', 0.00),
(5, 2, 'L', 6000.00),
(6, 3, 'M', 0.00),
(7, 3, 'L', 8000.00),
(8, 4, 'STD', 0.00);

INSERT IGNORE INTO tblIngredient (id, code, name, base_unit, conversion_unit, conversion_rate, min_stock_threshold) VALUES
(1, 'ING-CAFE-RB', 'Hạt cà phê Robusta rang xay', 'gram', 'Túi 1kg', 1000.0, 500.0),
(2, 'ING-SUADAC', 'Sữa đặc có đường', 'ml', 'Hộp 380g (300ml)', 300.0, 600.0),
(3, 'ING-SUATUOI', 'Sữa tươi thanh trùng', 'ml', 'Thùng 12L', 12000.0, 2000.0),
(4, 'ING-LY500', 'Ly nhựa 500ml + Nắp', 'piece', 'Cây 50 cái', 50.0, 50.0),
(5, 'ING-ONGHUT', 'Ống hút phi 8', 'piece', 'Bịch 100 cái', 100.0, 100.0),
(6, 'ING-TRANCHAU', 'Trân châu trắng 3Q', 'gram', 'Túi 2kg', 2000.0, 400.0);

INSERT IGNORE INTO tblRecipeItem (id, product_size_id, ingredient_id, quantity_required, wastage_percent) VALUES
(1, 1, 1, 18.0, 2.0),
(2, 1, 2, 35.0, 1.0),
(3, 1, 4, 1.0, 0.0),
(4, 1, 5, 1.0, 0.0),
(5, 2, 1, 22.0, 2.0),
(6, 2, 2, 45.0, 1.0),
(7, 2, 4, 1.0, 0.0),
(8, 2, 5, 1.0, 0.0),
(9, 4, 1, 15.0, 2.0),
(10, 4, 2, 30.0, 1.0),
(11, 4, 3, 120.0, 2.0),
(12, 4, 4, 1.0, 0.0),
(13, 8, 6, 40.0, 0.0);

INSERT IGNORE INTO tblBranchInventory (id, branch_id, ingredient_id, current_quantity) VALUES
(1, 1, 1, 5000.0),
(2, 1, 2, 3000.0),
(3, 1, 3, 12000.0),
(4, 1, 4, 200.0),
(5, 1, 5, 300.0),
(6, 1, 6, 2000.0);

INSERT IGNORE INTO tblSupplier (id, name, phone, email, address) VALUES
(1, 'Công ty Nguyên Liệu Pha Chế Việt', '0243999111', 'sales@nguyenlieuviet.vn', 'KCN Từ Liêm, Hà Nội');
