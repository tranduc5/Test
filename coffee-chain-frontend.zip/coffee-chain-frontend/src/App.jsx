import React, { useState } from 'react';
import { Coffee, QrCode, Monitor, ChefHat, Warehouse, UserCheck } from 'lucide-react';
import QrCustomerView from './components/QrCustomerView';
import PosCashierView from './components/PosCashierView';
import BaristaKdsView from './components/BaristaKdsView';
import InventoryRecipeView from './components/InventoryRecipeView';
import { setAuthCredentials } from './services/api';

export default function App() {
  const [activeModule, setActiveModule] = useState('POS'); // QR | POS | KDS | INVENTORY
  const [branchId, setBranchId] = useState(1);
  const [currentUser, setCurrentUser] = useState('admin_hd');
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  const handleSwitchAccount = (username) => {
    setCurrentUser(username);
    setAuthCredentials(username, '123456');
  };

  const triggerSync = () => setRefreshTrigger((prev) => prev + 1);

  return (
    <div className="min-h-screen flex flex-col bg-stone-100">
      {/* Top Navbar */}
      <header className="bg-coffee-900 text-white shadow-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-amber-500 rounded-xl text-coffee-900">
              <Coffee className="w-5 h-5" />
            </div>
            <div>
              <h1 className="font-extrabold text-sm tracking-wide">HN CÀ PHÊ • SMART CHAIN</h1>
              <p className="text-[11px] text-amber-200/80">Hệ thống Bán hàng & Kho định mức thời gian thực</p>
            </div>
          </div>

          {/* Navigation Tabs theo 4 Actor */}
          <nav className="flex flex-wrap items-center gap-1.5 bg-coffee-800/80 p-1 rounded-2xl">
            <button
              onClick={() => setActiveModule('QR')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition ${
                activeModule === 'QR' ? 'bg-amber-400 text-coffee-900' : 'text-stone-200 hover:bg-coffee-700'
              }`}
            >
              <QrCode className="w-4 h-4" /> Khách QR E-Menu
            </button>
            <button
              onClick={() => setActiveModule('POS')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition ${
                activeModule === 'POS' ? 'bg-amber-400 text-coffee-900' : 'text-stone-200 hover:bg-coffee-700'
              }`}
            >
              <Monitor className="w-4 h-4" /> Thu ngân POS
            </button>
            <button
              onClick={() => setActiveModule('KDS')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition ${
                activeModule === 'KDS' ? 'bg-amber-400 text-coffee-900' : 'text-stone-200 hover:bg-coffee-700'
              }`}
            >
              <ChefHat className="w-4 h-4" /> Barista KDS
            </button>
            <button
              onClick={() => setActiveModule('INVENTORY')}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition ${
                activeModule === 'INVENTORY' ? 'bg-amber-400 text-coffee-900' : 'text-stone-200 hover:bg-coffee-700'
              }`}
            >
              <Warehouse className="w-4 h-4" /> Kho & Công thức
            </button>
          </nav>

          {/* Bộ chọn Chi nhánh & Vai trò RBAC */}
          <div className="flex items-center gap-2 text-xs">
            <select
              value={branchId}
              onChange={(e) => setBranchId(Number(e.target.value))}
              className="bg-coffee-800 border border-coffee-600 rounded-xl px-2.5 py-1.5 text-white font-semibold"
            >
              <option value={1}>CN Hà Đông</option>
              <option value={2}>CN Cầu Giấy</option>
            </select>

            <div className="flex items-center gap-1 bg-coffee-800 border border-coffee-600 rounded-xl px-2.5 py-1.5">
              <UserCheck className="w-3.5 h-3.5 text-amber-300" />
              <select
                value={currentUser}
                onChange={(e) => handleSwitchAccount(e.target.value)}
                className="bg-transparent text-white font-semibold focus:outline-none"
              >
                <option value="admin_hd" className="text-stone-900">Quản lý (admin_hd)</option>
                <option value="cashier_hd" className="text-stone-900">Thu ngân (cashier_hd)</option>
                <option value="barista_hd" className="text-stone-900">Pha chế (barista_hd)</option>
                <option value="store_hd" className="text-stone-900">Thủ kho (store_hd)</option>
              </select>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6">
        {activeModule === 'QR' && <QrCustomerView onOrderUpdated={triggerSync} />}
        {activeModule === 'POS' && (
          <PosCashierView branchId={branchId} refreshTrigger={refreshTrigger} onOrderUpdated={triggerSync} />
        )}
        {activeModule === 'KDS' && (
          <BaristaKdsView branchId={branchId} refreshTrigger={refreshTrigger} onOrderUpdated={triggerSync} />
        )}
        {activeModule === 'INVENTORY' && (
          <InventoryRecipeView branchId={branchId} refreshTrigger={refreshTrigger} onInventoryChanged={triggerSync} />
        )}
      </main>
    </div>
  );
}
