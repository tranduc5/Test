import React, { useState, useEffect } from 'react';
import { Monitor, Trash2, CreditCard, Banknote, History, XCircle, CheckCircle } from 'lucide-react';
import { CoffeeApi } from '../services/api';

export default function PosCashierView({ branchId, refreshTrigger, onOrderUpdated }) {
  const [subTab, setSubTab] = useState('POS'); // POS | HISTORY
  const [menu, setMenu] = useState([]);
  const [orderItems, setOrderItems] = useState([]);
  const [tableId, setTableId] = useState('');
  const [discountAmount, setDiscountAmount] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState('CASH');
  const [customerGiven, setCustomerGiven] = useState('');
  const [showPayModal, setShowPayModal] = useState(false);
  const [ordersHistory, setOrdersHistory] = useState([]);
  const [toast, setToast] = useState(null);

  const loadData = async () => {
    try {
      const [menuRes, histRes] = await Promise.all([
        CoffeeApi.getBranchMenu(branchId),
        CoffeeApi.getBranchOrders(branchId),
      ]);
      setMenu(menuRes.data || []);
      setOrdersHistory(histRes.data || []);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    loadData();
  }, [branchId, refreshTrigger]);

  const showNotice = (type, msg) => {
    setToast({ type, msg });
    setTimeout(() => setToast(null), 4000);
  };

  const addProductSizeToOrder = (product, size) => {
    if (!product.availableAtBranch) return;
    const unitPrice = Number(product.basePrice) + Number(size.priceAdjustment || 0);
    setOrderItems((prev) => {
      const existing = prev.find((i) => i.productSizeId === size.id);
      if (existing) {
        return prev.map((i) => (i.productSizeId === size.id ? { ...i, quantity: i.quantity + 1 } : i));
      }
      return [
        ...prev,
        {
          productSizeId: size.id,
          name: `${product.name} (${size.sizeName})`,
          unitPrice,
          quantity: 1,
          sugarLevel: '100%',
          iceLevel: 'Đá vừa',
          note: '',
        },
      ];
    });
  };

  const totalAmount = orderItems.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0);
  const finalAmount = Math.max(0, totalAmount - Number(discountAmount || 0));
  const changeAmount = Math.max(0, Number(customerGiven || 0) - finalAmount);

  const handleCompletePosPayment = async () => {
    try {
      const res = await CoffeeApi.createAndPayPos({
        branchId,
        tableId: tableId ? Number(tableId) : null,
        discountAmount: Number(discountAmount || 0),
        paymentMethod,
        items: orderItems.map((i) => ({
          productSizeId: i.productSizeId,
          quantity: i.quantity,
          sugarLevel: i.sugarLevel,
          iceLevel: i.iceLevel,
          note: i.note,
        })),
      });
      setShowPayModal(false);
      setOrderItems([]);
      setDiscountAmount(0);
      setCustomerGiven('');
      showNotice('success', `Thanh toán thành công HĐ ${res.data.invoiceCode}! Đã tự động trừ kho & đẩy đơn tới Barista.`);
      loadData();
      onOrderUpdated?.();
    } catch (err) {
      showNotice('error', err.response?.data?.message || 'Không đủ nguyên liệu tồn kho!');
    }
  };

  const handleCancelOrder = async (orderId) => {
    const reason = window.prompt('Nhập lý do hủy đơn (Hệ thống sẽ hoàn lại nguyên liệu vào kho):', 'Khách đổi ý / Sự cố nguyên liệu');
    if (!reason) return;
    try {
      await CoffeeApi.cancelOrder(orderId, reason);
      showNotice('success', 'Đã hủy đơn và hoàn trả tồn kho tự động (UC15 & UC23)!');
      loadData();
      onOrderUpdated?.();
    } catch (err) {
      showNotice('error', err.response?.data?.message || 'Không thể hủy đơn này');
    }
  };

  return (
    <div className="space-y-4">
      {/* Sub-navigation POS / Lịch sử đơn */}
      <div className="flex items-center justify-between bg-white p-3 rounded-2xl shadow-sm border border-stone-200">
        <div className="flex gap-2">
          <button
            onClick={() => setSubTab('POS')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 ${
              subTab === 'POS' ? 'bg-coffee-800 text-white' : 'bg-stone-100 text-stone-600'
            }`}
          >
            <Monitor className="w-4 h-4" /> Bán hàng tại quầy (POS)
          </button>
          <button
            onClick={() => setSubTab('HISTORY')}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 ${
              subTab === 'HISTORY' ? 'bg-coffee-800 text-white' : 'bg-stone-100 text-stone-600'
            }`}
          >
            <History className="w-4 h-4" /> Lịch sử đơn & Hủy đơn (UC15/UC16)
          </button>
        </div>
        {toast && (
          <div className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 ${
            toast.type === 'success' ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
          }`}>
            {toast.type === 'success' ? <CheckCircle className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
            {toast.msg}
          </div>
        )}
      </div>

      {subTab === 'POS' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Cột trái: Danh sách món */}
          <div className="lg:col-span-7 bg-white p-5 rounded-3xl shadow-sm border border-stone-200">
            <h3 className="font-bold text-sm text-stone-700 mb-4">Danh mục thực đơn tại quầy</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {menu.map((prod) => (
                <div
                  key={prod.id}
                  className={`p-4 rounded-2xl border ${
                    prod.availableAtBranch ? 'border-stone-200 bg-stone-50/50' : 'border-stone-200 bg-stone-100 opacity-50'
                  }`}
                >
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <span className="text-[10px] font-bold text-coffee-600 uppercase">{prod.categoryName}</span>
                      <h4 className="font-bold text-sm text-stone-800">{prod.name}</h4>
                    </div>
                    {!prod.availableAtBranch && (
                      <span className="text-[10px] font-bold bg-red-100 text-red-600 px-2 py-0.5 rounded-full">Hết kho</span>
                    )}
                  </div>
                  <div className="flex flex-wrap gap-1.5 mt-3">
                    {prod.sizes?.map((sz) => (
                      <button
                        key={sz.id}
                        disabled={!prod.availableAtBranch}
                        onClick={() => addProductSizeToOrder(prod, sz)}
                        className="px-2.5 py-1.5 bg-white hover:bg-coffee-700 hover:text-white border border-stone-300 rounded-lg text-xs font-semibold transition"
                      >
                        Size {sz.sizeName} • {(Number(prod.basePrice) + Number(sz.priceAdjustment)).toLocaleString()}đ
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Cột phải: Hóa đơn tạm tính */}
          <div className="lg:col-span-5 bg-white p-5 rounded-3xl shadow-sm border border-stone-200 flex flex-col justify-between min-h-[540px]">
            <div>
              <div className="flex items-center justify-between pb-3 border-b border-stone-100">
                <h3 className="font-bold text-sm text-stone-800">Chi tiết đơn hàng hiện tại</h3>
                <select
                  value={tableId}
                  onChange={(e) => setTableId(e.target.value)}
                  className="text-xs border border-stone-200 rounded-lg px-2.5 py-1.5 font-medium"
                >
                  <option value="">Mang về (Take-away)</option>
                  <option value="1">Tại bàn - Bàn 01</option>
                  <option value="2">Tại bàn - Bàn 02</option>
                  <option value="3">Tại bàn - Bàn 08</option>
                </select>
              </div>

              {orderItems.length === 0 ? (
                <div className="py-20 text-center text-xs text-stone-400">
                  Chưa có món nào được chọn. Nhấn vào kích cỡ món bên trái để thêm.
                </div>
              ) : (
                <div className="divide-y divide-stone-100 max-h-72 overflow-y-auto my-2">
                  {orderItems.map((item) => (
                    <div key={item.productSizeId} className="py-2.5 flex items-center justify-between text-xs">
                      <div className="flex-1">
                        <p className="font-bold text-stone-800">{item.name}</p>
                        <p className="text-stone-400">{item.unitPrice.toLocaleString()}đ x {item.quantity}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-coffee-800">
                          {(item.unitPrice * item.quantity).toLocaleString()}đ
                        </span>
                        <button
                          onClick={() => setOrderItems((prev) => prev.filter((i) => i.productSizeId !== item.productSizeId))}
                          className="p-1 text-red-500 hover:bg-red-50 rounded"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="border-t border-stone-200 pt-4 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="text-stone-500">Giảm giá / Voucher (VNĐ):</span>
                <input
                  type="number"
                  min="0"
                  value={discountAmount}
                  onChange={(e) => setDiscountAmount(e.target.value)}
                  className="w-28 text-right border border-stone-200 rounded-lg px-2 py-1 font-semibold"
                />
              </div>
              <div className="flex justify-between text-base font-extrabold text-coffee-900">
                <span>Khách cần trả:</span>
                <span>{finalAmount.toLocaleString('vi-VN')} đ</span>
              </div>
              <button
                disabled={orderItems.length === 0}
                onClick={() => {
                  setCustomerGiven(String(finalAmount));
                  setShowPayModal(true);
                }}
                className="w-full py-3.5 bg-coffee-800 disabled:bg-stone-300 hover:bg-coffee-900 text-white font-bold text-sm rounded-2xl shadow-md transition"
              >
                Thanh toán & Chuyển pha chế
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* SCR-08: Lịch sử đơn hàng & Hủy đơn hoàn kho */
        <div className="bg-white p-5 rounded-3xl shadow-sm border border-stone-200 overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-stone-200 text-stone-500 uppercase">
                <th className="py-3 px-2">Mã đơn</th>
                <th className="py-3 px-2">Kênh</th>
                <th className="py-3 px-2">Bàn</th>
                <th className="py-3 px-2">Chi tiết món</th>
                <th className="py-3 px-2">Tổng tiền</th>
                <th className="py-3 px-2">Trạng thái</th>
                <th className="py-3 px-2 text-right">Thao tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {ordersHistory.map((ord) => (
                <tr key={ord.id} className="hover:bg-stone-50">
                  <td className="py-3 px-2 font-bold text-stone-800">{ord.orderCode}</td>
                  <td className="py-3 px-2">
                    <span className="px-2 py-0.5 rounded bg-stone-100 font-semibold">{ord.orderChannel}</span>
                  </td>
                  <td className="py-3 px-2">{ord.table?.tableName || 'Mang về'}</td>
                  <td className="py-3 px-2">
                    {ord.listOrderDetails?.map((d) => (
                      <div key={d.id}>• {d.productSize?.product?.name} (Size {d.productSize?.sizeName}) x{d.quantity}</div>
                    ))}
                  </td>
                  <td className="py-3 px-2 font-bold text-coffee-800">{Number(ord.finalAmount).toLocaleString()}đ</td>
                  <td className="py-3 px-2">
                    <span className={`px-2.5 py-1 rounded-full font-bold text-[10px] ${
                      ord.status === 'COMPLETED' ? 'bg-emerald-100 text-emerald-700' :
                      ord.status === 'CANCELLED' ? 'bg-red-100 text-red-700' :
                      'bg-amber-100 text-amber-800'
                    }`}>
                      {ord.status}
                    </span>
                  </td>
                  <td className="py-3 px-2 text-right">
                    {(ord.status === 'PAID_WAITING' || ord.status === 'PREPARING') && (
                      <button
                        onClick={() => handleCancelOrder(ord.id)}
                        className="px-3 py-1.5 bg-red-50 hover:bg-red-100 text-red-600 font-bold rounded-lg"
                      >
                        Hủy đơn & Hoàn kho
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* SCR-07: Modal Thanh toán POS */}
      {showPayModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <h3 className="font-bold text-base text-stone-800">Xác nhận thanh toán POS</h3>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setPaymentMethod('CASH')}
                className={`p-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-2 ${
                  paymentMethod === 'CASH' ? 'bg-coffee-800 text-white border-coffee-800' : 'border-stone-200'
                }`}
              >
                <Banknote className="w-4 h-4" /> Tiền mặt
              </button>
              <button
                onClick={() => setPaymentMethod('VIETQR')}
                className={`p-3 rounded-xl border text-xs font-bold flex items-center justify-center gap-2 ${
                  paymentMethod === 'VIETQR' ? 'bg-coffee-800 text-white border-coffee-800' : 'border-stone-200'
                }`}
              >
                <CreditCard className="w-4 h-4" /> Chuyển khoản QR
              </button>
            </div>

            <div className="bg-stone-50 p-4 rounded-2xl space-y-2 text-xs">
              <div className="flex justify-between">
                <span>Tổng thanh toán:</span>
                <span className="font-extrabold text-sm text-coffee-900">{finalAmount.toLocaleString()} đ</span>
              </div>
              {paymentMethod === 'CASH' && (
                <>
                  <div className="flex items-center justify-between">
                    <span>Tiền khách đưa:</span>
                    <input
                      type="number"
                      value={customerGiven}
                      onChange={(e) => setCustomerGiven(e.target.value)}
                      className="w-32 text-right border border-stone-300 rounded-lg px-2 py-1 font-bold"
                    />
                  </div>
                  <div className="flex justify-between text-emerald-700 font-bold pt-1 border-t">
                    <span>Tiền thối lại khách:</span>
                    <span>{changeAmount.toLocaleString()} đ</span>
                  </div>
                </>
              )}
            </div>

            <div className="flex gap-2">
              <button onClick={() => setShowPayModal(false)} className="flex-1 py-2.5 bg-stone-100 rounded-xl text-xs font-bold">
                Đóng
              </button>
              <button onClick={handleCompletePosPayment} className="flex-1 py-2.5 bg-emerald-600 text-white rounded-xl text-xs font-bold">
                Xác nhận hoàn tất
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
