import React, { useState, useEffect } from 'react';
import { Coffee, Play, CheckCircle2, RefreshCw, AlertTriangle } from 'lucide-react';
import { CoffeeApi } from '../services/api';

export default function BaristaKdsView({ branchId, refreshTrigger, onOrderUpdated }) {
  const [queue, setQueue] = useState([]);

  const loadQueue = async () => {
    try {
      const res = await CoffeeApi.getKdsQueue(branchId);
      setQueue(res.data || []);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    loadQueue();
    const interval = setInterval(loadQueue, 5000);
    return () => clearInterval(interval);
  }, [branchId, refreshTrigger]);

  const handleStatusChange = async (orderId, nextStatus) => {
    try {
      await CoffeeApi.updateKdsStatus(orderId, nextStatus);
      loadQueue();
      onOrderUpdated?.();
    } catch (err) {
      alert(err.response?.data?.message || 'Lỗi cập nhật trạng thái');
    }
  };

  const handleReportIncident = async (orderId) => {
    const ok = window.confirm('Báo sự cố thiếu nguyên liệu thực tế tại quầy? Hệ thống sẽ hủy đơn và hoàn kho cho Thu ngân xử lý.');
    if (!ok) return;
    try {
      await CoffeeApi.cancelOrder(orderId, 'Barista báo sự cố thiếu nguyên liệu thực tế');
      loadQueue();
      onOrderUpdated?.();
    } catch (err) {
      alert(err.response?.data?.message || 'Lỗi báo sự cố');
    }
  };

  return (
    <div className="space-y-4">
      <div className="bg-white p-4 rounded-2xl shadow-sm border border-stone-200 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="p-2 bg-amber-100 text-amber-800 rounded-xl">
            <Coffee className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-bold text-sm text-stone-800">Màn hình Điều phối Pha chế (Barista KDS - FIFO)</h2>
            <p className="text-xs text-stone-500">Hiển thị các đơn đã thanh toán theo thứ tự thời gian đặt</p>
          </div>
        </div>
        <button
          onClick={loadQueue}
          className="px-3.5 py-2 bg-stone-100 hover:bg-stone-200 rounded-xl text-xs font-bold flex items-center gap-1.5"
        >
          <RefreshCw className="w-3.5 h-3.5" /> Làm mới ({queue.length} đơn)
        </button>
      </div>

      {queue.length === 0 ? (
        <div className="bg-white rounded-3xl p-16 text-center border border-stone-200 text-stone-400 text-sm">
          Hiện không có đơn hàng nào đang chờ pha chế.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {queue.map((order) => (
            <div
              key={order.id}
              className={`rounded-3xl border-2 p-5 bg-white shadow-sm flex flex-col justify-between ${
                order.status === 'PREPARING' ? 'border-amber-400' : 'border-stone-200'
              }`}
            >
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-stone-100">
                  <div>
                    <span className="text-xs font-extrabold text-coffee-800">{order.orderCode}</span>
                    <p className="text-xs font-bold text-stone-600">
                      {order.table ? order.table.tableName : 'Khách mang về'} • {order.orderChannel}
                    </p>
                  </div>
                  <span className={`px-2.5 py-1 rounded-full text-[10px] font-extrabold ${
                    order.status === 'PREPARING' ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-700'
                  }`}>
                    {order.status === 'PREPARING' ? 'ĐANG PHA CHẾ' : 'CHỜ PHA CHẾ'}
                  </span>
                </div>

                <div className="py-3 space-y-2.5">
                  {order.listOrderDetails?.map((d) => (
                    <div key={d.id} className="bg-stone-50 p-2.5 rounded-xl text-xs">
                      <div className="font-bold text-stone-800 flex justify-between">
                        <span>{d.productSize?.product?.name} (Size {d.productSize?.sizeName})</span>
                        <span className="text-coffee-700">x{d.quantity}</span>
                      </div>
                      <p className="text-[11px] text-stone-500 mt-0.5">
                        Đường: <b>{d.sugarLevel || '100%'}</b> | Đá: <b>{d.iceLevel || 'Vừa'}</b>
                      </p>
                      {d.note && (
                        <p className="text-[11px] text-red-600 font-semibold mt-0.5">Ghi chú: {d.note}</p>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-3 border-t border-stone-100 space-y-2">
                {order.status === 'PAID_WAITING' ? (
                  <button
                    onClick={() => handleStatusChange(order.id, 'PREPARING')}
                    className="w-full py-2.5 bg-amber-500 hover:bg-amber-600 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5"
                  >
                    <Play className="w-4 h-4" /> Bắt đầu pha chế
                  </button>
                ) : (
                  <button
                    onClick={() => handleStatusChange(order.id, 'COMPLETED')}
                    className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5"
                  >
                    <CheckCircle2 className="w-4 h-4" /> Hoàn thành pha chế
                  </button>
                )}

                <button
                  onClick={() => handleReportIncident(order.id)}
                  className="w-full py-1.5 text-red-600 hover:bg-red-50 text-[11px] font-semibold rounded-lg flex items-center justify-center gap-1"
                >
                  <AlertTriangle className="w-3.5 h-3.5" /> Báo sự cố thiếu nguyên liệu thực tế (UC17.3)
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
