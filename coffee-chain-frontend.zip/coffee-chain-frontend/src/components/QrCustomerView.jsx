import React, { useState, useEffect } from 'react';
import { QrCode, ShoppingBag, Plus, Minus, CheckCircle2, Clock, Sparkles, X } from 'lucide-react';
import { CoffeeApi } from '../services/api';

export default function QrCustomerView({ onOrderUpdated }) {
  const [qrToken, setQrToken] = useState('QR-CNHD-T08');
  const [tableInfo, setTableInfo] = useState({ branchName: '', tableName: '' });
  const [menu, setMenu] = useState([]);
  const [cart, setCart] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [customForm, setCustomForm] = useState({ sizeId: null, sugar: '100%', ice: 'Đá vừa', note: '', qty: 1 });
  const [showCart, setShowCart] = useState(false);
  const [pendingOrder, setPendingOrder] = useState(null);
  const [paidInvoice, setPaidInvoice] = useState(null);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const loadMenu = async (token = qrToken) => {
    try {
      setErrorMsg('');
      const res = await CoffeeApi.getQrMenu(token);
      setTableInfo({ branchName: res.data.branchName, tableName: res.data.tableName });
      setMenu(res.data.menu || []);
    } catch (err) {
      setErrorMsg(err.response?.data?.message || 'Mã bàn không khả dụng, vui lòng liên hệ nhân viên');
    }
  };

  useEffect(() => {
    loadMenu();
  }, []);

  const openCustomize = (product) => {
    if (!product.availableAtBranch) return;
    const defaultSize = product.sizes?.[0];
    setSelectedProduct(product);
    setCustomForm({
      sizeId: defaultSize?.id || null,
      sugar: '100%',
      ice: 'Đá vừa',
      note: '',
      qty: 1,
    });
  };

  const addToCart = () => {
    const sizeObj = selectedProduct.sizes.find((s) => s.id === Number(customForm.sizeId));
    const unitPrice = Number(selectedProduct.basePrice) + Number(sizeObj?.priceAdjustment || 0);
    setCart((prev) => [
      ...prev,
      {
        key: Date.now(),
        productName: selectedProduct.name,
        productSizeId: sizeObj.id,
        sizeName: sizeObj.sizeName,
        unitPrice,
        quantity: customForm.qty,
        sugarLevel: customForm.sugar,
        iceLevel: customForm.ice,
        note: customForm.note,
      },
    ]);
    setSelectedProduct(null);
  };

  const totalAmount = cart.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0);

  const handleCreateQrOrder = async () => {
    try {
      setLoading(true);
      setErrorMsg('');
      const res = await CoffeeApi.createQrOrder({
        qrToken,
        items: cart.map((c) => ({
          productSizeId: c.productSizeId,
          quantity: c.quantity,
          sugarLevel: c.sugarLevel,
          iceLevel: c.iceLevel,
          note: c.note,
        })),
      });
      setPendingOrder(res.data);
      setShowCart(false);
    } catch (err) {
      setErrorMsg(err.response?.data?.message || 'Lỗi tạo đơn hàng');
    } finally {
      setLoading(false);
    }
  };

  const handleConfirmVietQr = async () => {
    try {
      setLoading(true);
      setErrorMsg('');
      const res = await CoffeeApi.confirmQrPayment(pendingOrder.id);
      setPaidInvoice(res.data);
      setPendingOrder(null);
      setCart([]);
      loadMenu();
      onOrderUpdated?.();
    } catch (err) {
      setErrorMsg(err.response?.data?.message || 'Món vừa hết nguyên liệu, giao dịch đã hủy!');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto bg-white min-h-[780px] rounded-3xl shadow-xl border border-stone-200 overflow-hidden flex flex-col">
      {/* Header E-Menu (SCR-01) */}
      <div className="bg-coffee-800 text-white p-5">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <QrCode className="w-6 h-6 text-amber-300" />
            <div>
              <h2 className="font-bold text-base">{tableInfo.branchName || 'HN Cà Phê'}</h2>
              <p className="text-xs text-amber-200">{tableInfo.tableName || 'Quét QR tại bàn'}</p>
            </div>
          </div>
          <select
            value={qrToken}
            onChange={(e) => {
              setQrToken(e.target.value);
              loadMenu(e.target.value);
            }}
            className="bg-coffee-700 text-xs text-white px-2.5 py-1.5 rounded-lg border border-coffee-600"
          >
            <option value="QR-CNHD-T01">Bàn 01</option>
            <option value="QR-CNHD-T02">Bàn 02</option>
            <option value="QR-CNHD-T08">Bàn 08</option>
          </select>
        </div>
        {errorMsg && (
          <div className="bg-red-500/20 border border-red-300 text-red-100 text-xs p-2.5 rounded-xl">
            {errorMsg}
          </div>
        )}
      </div>

      {/* SCR-04: Biên lai điện tử sau khi thanh toán thành công */}
      {paidInvoice && (
        <div className="m-4 p-4 bg-emerald-50 border border-emerald-200 rounded-2xl">
          <div className="flex items-center gap-2 text-emerald-700 font-bold mb-1">
            <CheckCircle2 className="w-5 h-5" />
            <span>Thanh toán VietQR thành công!</span>
          </div>
          <p className="text-xs text-stone-600">Mã hóa đơn: <b>{paidInvoice.invoiceCode}</b></p>
          <p className="text-xs text-stone-600">Mã đơn pha chế: <b>{paidInvoice.order?.orderCode}</b></p>
          <p className="text-xs text-emerald-700 mt-1 font-medium">
            Trạng thái: Đã trừ kho tự động & chuyển sang Barista
          </p>
          <button
            onClick={() => setPaidInvoice(null)}
            className="mt-3 w-full py-1.5 bg-emerald-600 text-white text-xs font-semibold rounded-xl"
          >
            Tiếp tục gọi thêm món
          </button>
        </div>
      )}

      {/* SCR-03: Cổng thanh toán VietQR động */}
      {pendingOrder && (
        <div className="m-4 p-5 bg-amber-50 border-2 border-amber-300 rounded-2xl text-center">
          <div className="flex items-center justify-center gap-1.5 text-amber-800 font-bold mb-2">
            <Clock className="w-4 h-4" />
            <span>Thanh toán trực tuyến VietQR</span>
          </div>
          <div className="bg-white p-4 rounded-2xl inline-block shadow-sm border border-stone-200 my-2">
            <QrCode className="w-32 h-32 text-stone-800 mx-auto" />
            <p className="text-[11px] text-stone-500 mt-1">Nội dung: {pendingOrder.orderCode}</p>
          </div>
          <p className="text-lg font-extrabold text-coffee-800">
            {Number(pendingOrder.finalAmount).toLocaleString('vi-VN')} đ
          </p>
          <div className="flex gap-2 mt-4">
            <button
              onClick={() => setPendingOrder(null)}
              className="flex-1 py-2.5 bg-stone-200 text-stone-700 text-xs font-semibold rounded-xl"
            >
              Hủy
            </button>
            <button
              disabled={loading}
              onClick={handleConfirmVietQr}
              className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow"
            >
              {loading ? 'Đang xử lý...' : 'Xác nhận đã chuyển khoản'}
            </button>
          </div>
        </div>
      )}

      {/* Lưới thực đơn E-Menu */}
      <div className="p-4 flex-1 overflow-y-auto space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-sm text-stone-700 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-amber-500" /> Thực đơn tại bàn
          </h3>
          <span className="text-[11px] text-stone-400">Tự động khóa món hết nguyên liệu</span>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {menu.map((item) => (
            <div
              key={item.id}
              onClick={() => openCustomize(item)}
              className={`p-3.5 rounded-2xl border transition flex flex-col justify-between ${
                item.availableAtBranch
                  ? 'bg-white border-stone-200 hover:border-coffee-600 cursor-pointer shadow-sm'
                  : 'bg-stone-100 border-stone-200 opacity-60 cursor-not-allowed'
              }`}
            >
              <div>
                <span className="text-[10px] uppercase tracking-wider text-coffee-600 font-semibold">
                  {item.categoryName}
                </span>
                <h4 className="font-bold text-sm text-stone-800 mt-0.5">{item.name}</h4>
              </div>
              <div className="mt-3 flex items-center justify-between">
                <span className="font-bold text-xs text-coffee-800">
                  {Number(item.basePrice).toLocaleString('vi-VN')}đ
                </span>
                {item.availableAtBranch ? (
                  <span className="w-6 h-6 rounded-full bg-coffee-700 text-white flex items-center justify-center">
                    <Plus className="w-3.5 h-3.5" />
                  </span>
                ) : (
                  <span className="text-[10px] font-bold px-2 py-0.5 bg-red-100 text-red-600 rounded-full">
                    Tạm hết
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Thanh Giỏ hàng dưới đáy */}
      {cart.length > 0 && !pendingOrder && (
        <div className="p-4 bg-white border-t border-stone-200">
          <button
            onClick={() => setShowCart(true)}
            className="w-full py-3 px-4 bg-coffee-800 hover:bg-coffee-900 text-white rounded-2xl font-bold text-sm flex items-center justify-between shadow-lg"
          >
            <span className="flex items-center gap-2">
              <ShoppingBag className="w-4 h-4 text-amber-300" />
              Giỏ hàng ({cart.reduce((s, i) => s + i.quantity, 0)} món)
            </span>
            <span>{totalAmount.toLocaleString('vi-VN')} đ</span>
          </button>
        </div>
      )}

      {/* SCR-02: Popup Tùy chỉnh món */}
      {selectedProduct && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl max-w-sm w-full p-5 space-y-4 shadow-2xl">
            <div className="flex justify-between items-center">
              <h3 className="font-bold text-base text-stone-800">{selectedProduct.name}</h3>
              <button onClick={() => setSelectedProduct(null)} className="p-1 text-stone-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div>
              <label className="text-xs font-semibold text-stone-600 block mb-1.5">Kích cỡ (Size)</label>
              <div className="grid grid-cols-3 gap-2">
                {selectedProduct.sizes.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => setCustomForm({ ...customForm, sizeId: s.id })}
                    className={`py-2 px-2 rounded-xl border text-xs font-bold ${
                      Number(customForm.sizeId) === s.id
                        ? 'bg-coffee-700 text-white border-coffee-700'
                        : 'bg-stone-50 text-stone-700 border-stone-200'
                    }`}
                  >
                    Size {s.sizeName} (+{Number(s.priceAdjustment).toLocaleString()}đ)
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold text-stone-600 block mb-1">Mức đường</label>
                <select
                  value={customForm.sugar}
                  onChange={(e) => setCustomForm({ ...customForm, sugar: e.target.value })}
                  className="w-full border border-stone-200 rounded-xl p-2 text-xs"
                >
                  <option>100%</option>
                  <option>70%</option>
                  <option>50%</option>
                  <option>0%</option>
                </select>
              </div>
              <div>
                <label className="text-xs font-semibold text-stone-600 block mb-1">Mức đá</label>
                <select
                  value={customForm.ice}
                  onChange={(e) => setCustomForm({ ...customForm, ice: e.target.value })}
                  className="w-full border border-stone-200 rounded-xl p-2 text-xs"
                >
                  <option>Đá vừa</option>
                  <option>Ít đá</option>
                  <option>Nhiều đá</option>
                  <option>Nóng</option>
                </select>
              </div>
            </div>

            <div>
              <label className="text-xs font-semibold text-stone-600 block mb-1">Ghi chú pha chế</label>
              <input
                type="text"
                placeholder="VD: Ít sữa, mang ra cùng lúc..."
                value={customForm.note}
                onChange={(e) => setCustomForm({ ...customForm, note: e.target.value })}
                className="w-full border border-stone-200 rounded-xl p-2 text-xs"
              />
            </div>

            <div className="flex items-center justify-between pt-2">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setCustomForm({ ...customForm, qty: Math.max(1, customForm.qty - 1) })}
                  className="w-8 h-8 rounded-full bg-stone-100 flex items-center justify-center"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="font-bold text-sm">{customForm.qty}</span>
                <button
                  onClick={() => setCustomForm({ ...customForm, qty: customForm.qty + 1 })}
                  className="w-8 h-8 rounded-full bg-stone-100 flex items-center justify-center"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
              <button
                onClick={addToCart}
                className="px-5 py-2.5 bg-coffee-800 text-white text-xs font-bold rounded-xl"
              >
                Thêm vào giỏ
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Xác nhận giỏ hàng */}
      {showCart && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl max-w-sm w-full p-5 space-y-4 shadow-2xl">
            <div className="flex justify-between items-center">
              <h3 className="font-bold text-base">Xác nhận giỏ hàng</h3>
              <button onClick={() => setShowCart(false)}><X className="w-5 h-5 text-stone-400" /></button>
            </div>
            <div className="max-h-60 overflow-y-auto divide-y divide-stone-100">
              {cart.map((item) => (
                <div key={item.key} className="py-2.5 flex justify-between items-center text-xs">
                  <div>
                    <p className="font-bold text-stone-800">{item.productName} (Size {item.sizeName}) x{item.quantity}</p>
                    <p className="text-stone-400">Đường {item.sugarLevel} • {item.iceLevel} {item.note && `• ${item.note}`}</p>
                  </div>
                  <span className="font-bold">{(item.unitPrice * item.quantity).toLocaleString()}đ</span>
                </div>
              ))}
            </div>
            <div className="border-t pt-3 flex justify-between font-bold text-sm">
              <span>Tổng thanh toán</span>
              <span className="text-coffee-800">{totalAmount.toLocaleString('vi-VN')} đ</span>
            </div>
            <button
              disabled={loading}
              onClick={handleCreateQrOrder}
              className="w-full py-3 bg-coffee-800 text-white font-bold text-xs rounded-2xl shadow"
            >
              {loading ? 'Đang tạo mã VietQR...' : 'Thanh toán ngay qua VietQR'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
