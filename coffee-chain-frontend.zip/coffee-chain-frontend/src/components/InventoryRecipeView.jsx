import React, { useState, useEffect } from 'react';
import { Package, FlaskConical, ArrowDownToLine, ClipboardCheck, AlertTriangle, Plus } from 'lucide-react';
import { CoffeeApi } from '../services/api';

export default function InventoryRecipeView({ branchId, refreshTrigger, onInventoryChanged }) {
  const [tab, setTab] = useState('STOCK'); // STOCK | IMPORT | RECIPE
  const [inventories, setInventories] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [menu, setMenu] = useState([]);

  // Form nhập kho (UC21)
  const [importForm, setImportForm] = useState({
    ingredientId: 3,
    importQuantity: 2,
    importPrice: 360000,
    expiryDate: '2027-06-30',
  });

  // Form kiểm kê / xuất hủy (UC22)
  const [auditForm, setAuditForm] = useState({
    ingredientId: 1,
    quantity: 4800,
    isDisposal: false,
    reason: 'Kiểm kê cuối ca',
  });

  // Form công thức (UC19)
  const [selectedProductId, setSelectedProductId] = useState(1);
  const [selectedSizeId, setSelectedSizeId] = useState(1);
  const [recipes, setRecipes] = useState([]);
  const [newRecipeItem, setNewRecipeItem] = useState({ ingredientId: 1, quantityRequired: 20, wastagePercent: 2 });

  const loadAll = async () => {
    try {
      const [invRes, alertRes, txRes, menuRes] = await Promise.all([
        CoffeeApi.getBranchInventory(branchId),
        CoffeeApi.getLowStockAlerts(branchId),
        CoffeeApi.getStockTransactions(branchId),
        CoffeeApi.getBranchMenu(branchId),
      ]);
      setInventories(invRes.data || []);
      setAlerts(alertRes.data || []);
      setTransactions(txRes.data || []);
      setMenu(menuRes.data || []);
    } catch (e) {
      console.error(e);
    }
  };

  const loadRecipes = async (prodId = selectedProductId) => {
    try {
      const res = await CoffeeApi.getProductRecipes(prodId);
      setRecipes(res.data || []);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    loadAll();
    loadRecipes();
  }, [branchId, refreshTrigger]);

  const handleImportSubmit = async (e) => {
    e.preventDefault();
    try {
      await CoffeeApi.createImportReceipt({
        branchId,
        supplierId: 1,
        items: [
          {
            ingredientId: Number(importForm.ingredientId),
            importQuantity: Number(importForm.importQuantity),
            importPrice: Number(importForm.importPrice),
            expiryDate: importForm.expiryDate,
          },
        ],
      });
      alert('Nhập kho & Quy đổi đơn vị thành công!');
      loadAll();
      onInventoryChanged?.();
    } catch (err) {
      alert(err.response?.data?.message || 'Lỗi nhập kho');
    }
  };

  const handleAuditSubmit = async (e) => {
    e.preventDefault();
    try {
      await CoffeeApi.adjustOrDisposeStock({
        branchId,
        ingredientId: Number(auditForm.ingredientId),
        quantity: Number(auditForm.quantity),
        isDisposal: auditForm.isDisposal,
        reason: auditForm.reason,
      });
      alert('Đã cập nhật phiếu kiểm kê / xuất hủy kho!');
      loadAll();
      onInventoryChanged?.();
    } catch (err) {
      alert(err.response?.data?.message || 'Lỗi điều chỉnh kho');
    }
  };

  const handleAddRecipeRow = async () => {
    const currentList = recipes.map((r) => ({
      ingredientId: r.ingredient.id,
      quantityRequired: r.quantityRequired,
      wastagePercent: r.wastagePercent,
    }));
    const updated = [
      ...currentList.filter((i) => i.ingredientId !== Number(newRecipeItem.ingredientId)),
      {
        ingredientId: Number(newRecipeItem.ingredientId),
        quantityRequired: Number(newRecipeItem.quantityRequired),
        wastagePercent: Number(newRecipeItem.wastagePercent),
      },
    ];
    try {
      await CoffeeApi.saveProductSizeRecipes(selectedSizeId, updated);
      alert('Đã lưu định mức công thức!');
      loadRecipes();
      onInventoryChanged?.();
    } catch (err) {
      alert(err.response?.data?.message || 'Lỗi lưu công thức');
    }
  };

  return (
    <div className="space-y-4">
      {/* Sub-tabs */}
      <div className="bg-white p-3 rounded-2xl shadow-sm border border-stone-200 flex flex-wrap gap-2">
        <button
          onClick={() => setTab('STOCK')}
          className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 ${
            tab === 'STOCK' ? 'bg-coffee-800 text-white' : 'bg-stone-100 text-stone-600'
          }`}
        >
          <Package className="w-4 h-4" /> Tồn kho & Biến động ({alerts.length} cảnh báo)
        </button>
        <button
          onClick={() => setTab('IMPORT')}
          className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 ${
            tab === 'IMPORT' ? 'bg-coffee-800 text-white' : 'bg-stone-100 text-stone-600'
          }`}
        >
          <ArrowDownToLine className="w-4 h-4" /> Nhập kho & Kiểm kê (UC21/UC22)
        </button>
        <button
          onClick={() => setTab('RECIPE')}
          className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 ${
            tab === 'RECIPE' ? 'bg-coffee-800 text-white' : 'bg-stone-100 text-stone-600'
          }`}
        >
          <FlaskConical className="w-4 h-4" /> Định mức công thức Size S/M/L (UC19)
        </button>
      </div>

      {/* TAB 1: TỒN KHO & LỊCH SỬ BIẾN ĐỘNG */}
      {tab === 'STOCK' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          <div className="lg:col-span-7 bg-white p-5 rounded-3xl shadow-sm border border-stone-200">
            <h3 className="font-bold text-sm text-stone-800 mb-3">Tồn kho nguyên vật liệu tại chi nhánh</h3>
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b text-stone-500">
                  <th className="py-2">Mã NL</th>
                  <th className="py-2">Tên nguyên liệu</th>
                  <th className="py-2">Tồn hiện tại</th>
                  <th className="py-2">Ngưỡng tối thiểu</th>
                  <th className="py-2">Trạng thái</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {inventories.map((inv) => {
                  const isLow = inv.currentQuantity <= inv.ingredient.minStockThreshold;
                  return (
                    <tr key={inv.id}>
                      <td className="py-2.5 font-mono text-stone-500">{inv.ingredient.code}</td>
                      <td className="py-2.5 font-bold text-stone-800">{inv.ingredient.name}</td>
                      <td className="py-2.5 font-extrabold text-coffee-800">
                        {inv.currentQuantity.toLocaleString()} {inv.ingredient.baseUnit}
                      </td>
                      <td className="py-2.5 text-stone-500">
                        {inv.ingredient.minStockThreshold} {inv.ingredient.baseUnit}
                      </td>
                      <td className="py-2.5">
                        {isLow ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-red-100 text-red-700 font-bold text-[10px]">
                            <AlertTriangle className="w-3 h-3" /> Sắp hết
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 font-bold text-[10px]">
                            An toàn
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="lg:col-span-5 bg-white p-5 rounded-3xl shadow-sm border border-stone-200">
            <h3 className="font-bold text-sm text-stone-800 mb-3">Nhật ký biến động kho tự động (UC23)</h3>
            <div className="space-y-2.5 max-h-96 overflow-y-auto">
              {transactions.map((tx) => (
                <div key={tx.id} className="p-3 bg-stone-50 rounded-xl text-xs flex justify-between items-center">
                  <div>
                    <span className="font-bold text-stone-800">{tx.ingredient?.name}</span>
                    <p className="text-[11px] text-stone-500">{tx.note} ({tx.referenceCode})</p>
                  </div>
                  <span className={`font-extrabold ${tx.quantityChange < 0 ? 'text-red-600' : 'text-emerald-600'}`}>
                    {tx.quantityChange > 0 ? `+${tx.quantityChange}` : tx.quantityChange} {tx.ingredient?.baseUnit}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: NHẬP KHO QUY ĐỔI & KIỂM KÊ */}
      {tab === 'IMPORT' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Form Nhập kho (UC21) */}
          <form onSubmit={handleImportSubmit} className="bg-white p-5 rounded-3xl shadow-sm border border-stone-200 space-y-3">
            <h3 className="font-bold text-sm text-stone-800 flex items-center gap-2">
              <ArrowDownToLine className="w-4 h-4 text-coffee-700" /> Lập phiếu nhập kho & Quy đổi đơn vị (UC21)
            </h3>
            <div>
              <label className="text-xs font-semibold block mb-1">Chọn nguyên liệu</label>
              <select
                value={importForm.ingredientId}
                onChange={(e) => setImportForm({ ...importForm, ingredientId: e.target.value })}
                className="w-full border rounded-xl p-2 text-xs"
              >
                {inventories.map((inv) => (
                  <option key={inv.ingredient.id} value={inv.ingredient.id}>
                    {inv.ingredient.name} (1 {inv.ingredient.conversionUnit} = {inv.ingredient.conversionRate} {inv.ingredient.baseUnit})
                  </option>
                ))}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold block mb-1">Số lượng nhập (Đơn vị quy đổi)</label>
                <input
                  type="number"
                  step="0.1"
                  value={importForm.importQuantity}
                  onChange={(e) => setImportForm({ ...importForm, importQuantity: e.target.value })}
                  className="w-full border rounded-xl p-2 text-xs"
                  required
                />
              </div>
              <div>
                <label className="text-xs font-semibold block mb-1">Đơn giá nhập (VNĐ)</label>
                <input
                  type="number"
                  value={importForm.importPrice}
                  onChange={(e) => setImportForm({ ...importForm, importPrice: e.target.value })}
                  className="w-full border rounded-xl p-2 text-xs"
                  required
                />
              </div>
            </div>
            <div>
              <label className="text-xs font-semibold block mb-1">Hạn sử dụng (Bắt buộc &gt; hôm nay)</label>
              <input
                type="date"
                value={importForm.expiryDate}
                onChange={(e) => setImportForm({ ...importForm, expiryDate: e.target.value })}
                className="w-full border rounded-xl p-2 text-xs"
                required
              />
            </div>
            <button type="submit" className="w-full py-2.5 bg-coffee-800 text-white font-bold text-xs rounded-xl">
              Xác nhận nhập kho & Tự động quy đổi
            </button>
          </form>

          {/* Form Kiểm kê / Xuất hủy (UC22) */}
          <form onSubmit={handleAuditSubmit} className="bg-white p-5 rounded-3xl shadow-sm border border-stone-200 space-y-3">
            <h3 className="font-bold text-sm text-stone-800 flex items-center gap-2">
              <ClipboardCheck className="w-4 h-4 text-amber-600" /> Kiểm kê đối soát & Xuất hủy kho (UC22)
            </h3>
            <div>
              <label className="text-xs font-semibold block mb-1">Nguyên liệu kiểm kê / xuất hủy</label>
              <select
                value={auditForm.ingredientId}
                onChange={(e) => setAuditForm({ ...auditForm, ingredientId: e.target.value })}
                className="w-full border rounded-xl p-2 text-xs"
              >
                {inventories.map((inv) => (
                  <option key={inv.ingredient.id} value={inv.ingredient.id}>
                    {inv.ingredient.name} (Tồn HT: {inv.currentQuantity} {inv.ingredient.baseUnit})
                  </option>
                ))}
              </select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-semibold block mb-1">Loại nghiệp vụ</label>
                <select
                  value={String(auditForm.isDisposal)}
                  onChange={(e) => setAuditForm({ ...auditForm, isDisposal: e.target.value === 'true' })}
                  className="w-full border rounded-xl p-2 text-xs"
                >
                  <option value="false">Kiểm kê (Nhập tồn thực tế)</option>
                  <option value="true">Xuất hủy (Nhập lượng hủy)</option>
                </select>
              </div>
              <div>
                <label className="text-xs font-semibold block mb-1">Số lượng (Đơn vị chuẩn)</label>
                <input
                  type="number"
                  step="0.1"
                  value={auditForm.quantity}
                  onChange={(e) => setAuditForm({ ...auditForm, quantity: e.target.value })}
                  className="w-full border rounded-xl p-2 text-xs"
                  required
                />
              </div>
            </div>
            <div>
              <label className="text-xs font-semibold block mb-1">Lý do điều chỉnh</label>
              <input
                type="text"
                value={auditForm.reason}
                onChange={(e) => setAuditForm({ ...auditForm, reason: e.target.value })}
                className="w-full border rounded-xl p-2 text-xs"
                required
              />
            </div>
            <button type="submit" className="w-full py-2.5 bg-amber-600 text-white font-bold text-xs rounded-xl">
              Ghi nhận phiếu kiểm kê / xuất hủy
            </button>
          </form>
        </div>
      )}

      {/* TAB 3: THIẾT LẬP CÔNG THỨC PHA CHẾ (UC19) */}
      {tab === 'RECIPE' && (
        <div className="bg-white p-5 rounded-3xl shadow-sm border border-stone-200 space-y-4">
          <div className="flex flex-wrap items-center gap-3">
            <div>
              <label className="text-xs font-semibold block mb-1">Chọn đồ uống</label>
              <select
                value={selectedProductId}
                onChange={(e) => {
                  const id = Number(e.target.value);
                  setSelectedProductId(id);
                  const prod = menu.find((m) => m.id === id);
                  if (prod?.sizes?.[0]) setSelectedSizeId(prod.sizes[0].id);
                  loadRecipes(id);
                }}
                className="border rounded-xl px-3 py-2 text-xs font-bold"
              >
                {menu.map((m) => (
                  <option key={m.id} value={m.id}>{m.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-xs font-semibold block mb-1">Kích cỡ cấu hình (Size)</label>
              <select
                value={selectedSizeId}
                onChange={(e) => setSelectedSizeId(Number(e.target.value))}
                className="border rounded-xl px-3 py-2 text-xs font-bold"
              >
                {menu.find((m) => m.id === selectedProductId)?.sizes?.map((s) => (
                  <option key={s.id} value={s.id}>Size {s.sizeName}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-3 bg-stone-50 p-3.5 rounded-2xl items-end">
            <div>
              <label className="text-[11px] font-semibold block mb-1">Nguyên liệu cấu thành</label>
              <select
                value={newRecipeItem.ingredientId}
                onChange={(e) => setNewRecipeItem({ ...newRecipeItem, ingredientId: e.target.value })}
                className="w-full border rounded-xl p-2 text-xs bg-white"
              >
                {inventories.map((inv) => (
                  <option key={inv.ingredient.id} value={inv.ingredient.id}>
                    {inv.ingredient.name} ({inv.ingredient.baseUnit})
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-[11px] font-semibold block mb-1">Định lượng chuẩn</label>
              <input
                type="number"
                step="0.1"
                value={newRecipeItem.quantityRequired}
                onChange={(e) => setNewRecipeItem({ ...newRecipeItem, quantityRequired: e.target.value })}
                className="w-full border rounded-xl p-2 text-xs bg-white"
              />
            </div>
            <div>
              <label className="text-[11px] font-semibold block mb-1">Hao hụt cho phép (%)</label>
              <input
                type="number"
                step="0.5"
                value={newRecipeItem.wastagePercent}
                onChange={(e) => setNewRecipeItem({ ...newRecipeItem, wastagePercent: e.target.value })}
                className="w-full border rounded-xl p-2 text-xs bg-white"
              />
            </div>
            <button
              onClick={handleAddRecipeRow}
              className="py-2 px-4 bg-coffee-800 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1"
            >
              <Plus className="w-4 h-4" /> Cập nhật định mức
            </button>
          </div>

          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b text-stone-500">
                <th className="py-2">Nguyên liệu</th>
                <th className="py-2">Định lượng</th>
                <th className="py-2">Hao hụt (%)</th>
                <th className="py-2">Thực tế trừ kho / 1 ly</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {recipes.map((r) => (
                <tr key={r.id}>
                  <td className="py-2.5 font-bold">{r.ingredient?.name}</td>
                  <td className="py-2.5">{r.quantityRequired} {r.ingredient?.baseUnit}</td>
                  <td className="py-2.5">{r.wastagePercent}%</td>
                  <td className="py-2.5 font-bold text-coffee-800">
                    {(r.quantityRequired * (1 + r.wastagePercent / 100)).toFixed(2)} {r.ingredient?.baseUnit}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
