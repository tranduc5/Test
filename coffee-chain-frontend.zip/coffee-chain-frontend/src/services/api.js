import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

// Tự động gắn Basic Auth theo tài khoản đang đăng nhập
export const setAuthCredentials = (username, password) => {
  if (username && password) {
    const token = btoa(`${username}:${password}`);
    api.defaults.headers.common['Authorization'] = `Basic ${token}`;
  } else {
    delete api.defaults.headers.common['Authorization'];
  }
};

// Mặc định dùng tài khoản Quản lý để thao tác mượt mà toàn bộ màn hình demo
setAuthCredentials('admin_hd', '123456');

export const CoffeeApi = {
  // QR E-Menu (SCR-01 -> SCR-04)
  getQrMenu: (qrToken) => api.get(`/qr/tables/${qrToken}/menu`),
  createQrOrder: (payload) => api.post('/qr/orders', payload),
  confirmQrPayment: (orderId) => api.post(`/orders/${orderId}/confirm-payment`),

  // POS & Lịch sử đơn (SCR-06 -> SCR-08)
  getBranchMenu: (branchId) => api.get(`/menu/branches/${branchId}`),
  createAndPayPos: (payload) => api.post('/pos/orders', payload),
  getBranchOrders: (branchId) => api.get(`/pos/branches/${branchId}/orders`),
  cancelOrder: (orderId, reason) => api.post(`/orders/${orderId}/cancel`, null, { params: { reason } }),

  // Barista KDS (SCR-09)
  getKdsQueue: (branchId) => api.get(`/kds/branches/${branchId}/orders`),
  updateKdsStatus: (orderId, status) => api.patch(`/kds/orders/${orderId}/status`, null, { params: { status } }),

  // Công thức & Kho (SCR-11 -> SCR-13)
  getProductRecipes: (productId) => api.get(`/recipes/products/${productId}`),
  saveProductSizeRecipes: (sizeId, items) => api.post(`/recipes/product-sizes/${sizeId}`, items),
  getBranchInventory: (branchId) => api.get(`/inventory/branches/${branchId}`),
  getLowStockAlerts: (branchId) => api.get(`/inventory/branches/${branchId}/alerts`),
  createImportReceipt: (payload) => api.post('/inventory/import-receipts', payload),
  adjustOrDisposeStock: (params) => api.post('/inventory/stock-adjust', null, { params }),
  getStockTransactions: (branchId) => api.get(`/inventory/branches/${branchId}/transactions`),
};

export default api;
