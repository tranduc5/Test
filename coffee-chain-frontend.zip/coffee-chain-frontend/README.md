# Giao diện Frontend - Hệ thống Quản lý Chuỗi Cà phê Thông minh (React + Vite + Tailwind CSS)

## Hướng dẫn chạy giao diện
1. Đảm bảo Backend Spring Boot (`coffee-chain-backend`) đang chạy ở cổng `8080`.
2. Mở Terminal tại thư mục `coffee-chain-frontend` và chạy:
   ```bash
   npm install
   npm run dev
   ```
3. Mở trình duyệt truy cập: `http://localhost:5173`

## Các màn hình đã tích hợp đầy đủ
- **Khách QR E-Menu (`SCR-01` -> `SCR-04`):** Quét chọn bàn, tự động khóa món hết nguyên liệu tại chi nhánh, tùy chỉnh Size S/M/L, đường, đá, thanh toán VietQR động & biên lai điện tử.
- **Thu ngân POS (`SCR-06` -> `SCR-08`):** Lên đơn tại quầy, tính tiền thừa, thanh toán tự động trừ kho & lịch sử đơn hàng hỗ trợ hủy đơn hoàn kho (`UC15`).
- **Barista KDS (`SCR-09`):** Hàng đợi đơn theo thứ tự FIFO, chuyển trạng thái `Bắt đầu pha chế` -> `Hoàn thành pha chế` và nút `Báo sự cố thiếu nguyên liệu thực tế` (`UC17.3`).
- **Kho & Công thức (`SCR-11` -> `SCR-13`):** Theo dõi tồn kho & nhật ký biến động tự động (`UC23`), nhập kho quy đổi đơn vị (`UC21`), kiểm kê/xuất hủy (`UC22`), và thiết lập định mức công thức theo Size (`UC19`).
