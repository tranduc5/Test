/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        coffee: {
          50: '#fdf8f6',
          100: '#f2e8e5',
          200: '#eaddd7',
          600: '#8c5338',
          700: '#6f402a',
          800: '#55301f',
          900: '#3e2216',
        }
      }
    },
  },
  plugins: [],
}
